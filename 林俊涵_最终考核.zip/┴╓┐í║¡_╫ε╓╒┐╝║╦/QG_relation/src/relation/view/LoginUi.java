package relation.view;
import java.io.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.imageio.ImageIO;
import javax.swing.*;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.api.SubstanceSkin;
import org.jvnet.substance.api.skin.GeminiSkin;
import org.jvnet.substance.api.skin.GraphiteAquaSkin;
import org.jvnet.substance.api.skin.MagellanSkin;
import org.jvnet.substance.skin.ChallengerDeepSkin;
import org.jvnet.substance.skin.DustSkin;
import org.jvnet.substance.skin.EmeraldDuskSkin;
import org.jvnet.substance.skin.ModerateSkin;
import org.jvnet.substance.skin.OfficeBlue2007Skin;
import org.jvnet.substance.skin.SaharaSkin;


import relation.IO.IoRead;

public class LoginUi extends JFrame {
	public static String aimRelations;
	public static String aimRelations2;
	JFrame jframe;
	public static String str = "";
	public void showLogin() {

		// ����ͼƬ
		ImageIcon icon = new ImageIcon("C:\\Users\\Administrator\\Desktop\\����\\ͼƬ\\3-1FS11JA8.jpg");
		// Image im=new Image(icon);
		// ��ͼƬ����label��
		JLabel label = new JLabel(icon);
		// ����label�Ĵ�С
		label.setBounds(0, 25, icon.getIconWidth(), icon.getIconHeight());	
		JFrame frame = new JFrame("�����ϵ����ϵͳ");
		
		// ��ȡ���ڵĵڶ��㣬��label����
		frame.getLayeredPane().add(label, new Integer(Integer.MIN_VALUE));
		
		// ��ȡframe�Ķ�������,������Ϊ͸��
		 JMenuItem itemOpen =  new JMenuItem("�����ļ�λ��");
		JPanel j = (JPanel) frame.getContentPane();
		j.setOpaque(false);
		frame.setLayout(new GridLayout());
		JPanel panel = new JPanel();
		JMenuBar menuBar = new JMenuBar();
		JMenu menu1 = new JMenu("�����ı�");
		JMenu menu3 = new JMenu("ʹ��˵��");
		JFrame Text = new JFrame("�ı�λ��");
		Text.setBounds(430, 300, 600, 100);
		JPanel txt = new JPanel();
		menu1.add(itemOpen);
		JTextField jt = new JTextField(35);
		Text.add(txt);
		txt.add(jt);
		JButton b = new JButton("ȷ��");
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String id = jt.getText().trim();
				IoRead.ID = id;
				Text.setVisible(false);
			}
		});
		txt.add(b);
		itemOpen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Text.setVisible(true);
			}
		});
		/* ActionListener menuListener = e -> {  
			    String cmd = e.getActionCommand();  
			    ta.append("Click '" + cmd + "' menu item.\n");  
			    if (cmd.equals("Exit")) {  
			        System.exit(0);  
			    }  
             } ; 
             menu1.addActionListener(menuListener);*/
		JTextField jt4 = new JTextField(10);
		JTextField jt5 = new JTextField(10);
		JTextField jt6 = new JTextField(10);
		jt4.setBackground(Color.black);
		jt5.setBackground(Color.black);
		jt6.setBackground(Color.black);
		// frame.add(panel, BorderLayout.SOUTH);
		menuBar.add(menu1);
		menuBar.add(menu3);
		frame.setJMenuBar(menuBar);
		JTextField jta = new JTextField(10);
		JButton jb = new JButton("��ѯ��ϵ");
		JButton jb2 = new JButton("ɾ����ϵ");
		JButton jb3 = new JButton("���ӹ�ϵ");
		jb.setBounds(420, 370, 90, 30);
		jb2.setBounds(420, 410, 90, 30);
		jb3.setBounds(420, 450, 90, 30);
		//panel.add(jta);
		jb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String value1 = jt4.getText().trim();
				String value2 = jt5.getText().trim();
				IoRead.fianlSearch(value1, value2);
				jt6.setText("  "+aimRelations+"  "+aimRelations2);
			}
		});
		//C:\\Users\\Administrator\\Desktop\\����\\TestIO\\delected.txt
		jb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String value1 = jt4.getText().trim();
				String value2 = jt5.getText().trim();
	                try {
	                	FileOutputStream fos = new FileOutputStream("C:\\Users\\Administrator\\Desktop\\����\\TestIO\\delected.txt");
	                	PrintWriter pw = new PrintWriter(fos);
	                	str = str + value1 + "  "+value2+ "\r\n";
	                	// = index + value1 + "  "+value2+"\n";
	                	//pw.println(str);
	                	pw.append(str);
	                	pw.close();
	                } catch (Exception o) {
	                    o.printStackTrace();
	                }
			}
		});
		panel.add(jb);
		panel.add(jb2);
		panel.add(jb3);
		panel.add(jt4);
		panel.add(jt5);
		panel.add(jt6);
		jt4.setBounds(230, 370, 120, 30);
		jt5.setBounds(230, 410, 120, 30);
		jt6.setBounds(50, 450, 340, 30);
		panel.setLayout(null);
		// ��������Ϊ͸���ġ����򿴲���ͼƬ
		panel.setOpaque(false);
		frame.add(panel);
		frame.add(panel);
		frame.setBounds(280, 135, icon.getIconWidth(), icon.getIconHeight());
		frame.setVisible(true);
	}
	public static void main(String args[]) {
		JFrame.setDefaultLookAndFeelDecorated(true);
		JDialog.setDefaultLookAndFeelDecorated(true);
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				try {
					SubstanceLookAndFeel.setSkin(new DustSkin());
					LoginUi test = new LoginUi();
					test.showLogin();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}

class MyLabel extends JLabel {
	Image image = null;

	public void paint(Graphics g) {
		try {
			image = ImageIO.read(new File("C:\\Users\\Administrator\\Desktop\\����\\ͼƬ\\3-1FS11JA8.jpg"));
			g.drawImage(image, 0, 0, 800, 600, null);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}

	}

}

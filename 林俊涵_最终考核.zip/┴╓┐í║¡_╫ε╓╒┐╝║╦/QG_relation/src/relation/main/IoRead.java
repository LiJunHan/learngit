package relation.main;

import java.io.*;
import relation.dao.*;
import relation.model.*;

public class IoRead {
	/**
	 * ����ָ���ڵ�ķ���
	 * 
	 * @param args
	 */
	public static TreeNode search(TreeNode root, String aimName) {
		TreeNode aim;
		if (root != null) {
			if (root.getName().equals(aimName)) {
				aim = root;
				return aim;
			} else {
				for (TreeNode k : root.childlist) {
					if (k.getName().equals(aimName)) {
						aim = k;
						return aim;
					} else {
						TreeNode o = search(k, aimName);
						if (o != null) {
							return o;
						}
					}
				}
			}
		}
		return null;
	}

	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		TreeNode root = null;
		try {
			BufferedReader bw = new BufferedReader(
					new FileReader("C:\\Users\\Administrator\\Desktop\\����\\TestIO\\people.txt"));
			String s = null;
			while ((s = bw.readLine()) != null) {
				int[] no = new int[3];
				for (int i = 0, j = 0; i < s.length(); i++) {
					if (s.charAt(i) == '��' || s.charAt(i) == '��') { // ��¼�ļ�ĳ�е��﷨����������
						no[j] = i;
						j++;
					}
				}
				if (s.length() <= 8) { // ��һ�����﷨����
					if (s.charAt(2) == '��') { // ��һ���﷨����**�ǡ����ġ�����
						String relation = s.substring(no[1] + 1); // �жϹ�ϵ
						if (relation.equals("�ְ�")) { // ���ӹ�ϵ
							String k1 = s.substring(0, no[0]);
							String k2 = s.substring(no[0] + 1, no[1]);
							TreeNode f = IoRead.search(root, k1);
							TreeNode c = IoRead.search(root, k2);
							if (f == null && c == null) {
								TreeNode father = new TreeNode(k1);
								TreeNode son = new TreeNode(k2);
								father.setName(k1);
								son.setName(k2);
								TreeNode.insertFatherNode(father, son, 2);
								root = TreeNode.getHeadNode(father);
							}
							if (f != null && c == null) {
								TreeNode son = new TreeNode(k2);
								son.setName(k2);
								TreeNode.insertFatherNode(f, son, 2);
								root = TreeNode.getHeadNode(son);
							}
							if (f == null && c != null) {
								if (c.getFather() == null) {
									TreeNode father = new TreeNode(k1);
									father.setName(k1);
									TreeNode.insertFatherNode(father, c, 2);
									root = TreeNode.getHeadNode(father);
								} else {
									if (c.getFather().getName().equals(k1)) {
										TreeNode father = new TreeNode(k1);
										father.setName(k1);
										TreeNode.insertFatherNode(father, c, 2);
										root = TreeNode.getHeadNode(father);
									} else {
										System.out.println("�ı��߼����󣡣�");
									}
								}
							}
							if (f != null && c != null) {
								if (c.getFather() == null) {
									TreeNode father = new TreeNode(k1);
									father.setName(k1);
									TreeNode.insertFatherNode(father, c, 2);
									root = TreeNode.getHeadNode(father);
								} else {
									if (c.getFather().getName().equals(k1)) {
										TreeNode father = new TreeNode(k1);
										father.setName(k1);
										TreeNode.insertFatherNode(father, c, 2);
										root = TreeNode.getHeadNode(father);
									} else {
										System.out.println("�ı��߼����󣡣�");
									}
								}
							}
						}
						if (relation.equals("�ֵ�")) { // �ֵܹ�ϵ
							String k1 = s.substring(0, no[0]);
							String k2 = s.substring(no[0] + 1, no[1]);
							TreeNode b1 = IoRead.search(root, k1);
							TreeNode b2 = IoRead.search(root, k2);
							if (b1 == null && b2 == null) {
								TreeNode a1 = new TreeNode(k1);
								TreeNode a2 = new TreeNode(k2);
								TreeNode.insertBotherNode(a1, a2);
								root = TreeNode.getHeadNode(a1);
							}
							if (b1 != null && b2 == null) {
								TreeNode a2 = new TreeNode(k2);
								TreeNode.insertBotherNode(b1, a2);
								root = TreeNode.getHeadNode(b1);
							}
							if (b1 == null && b2 != null) {
								TreeNode a1 = new TreeNode(k1);
								TreeNode.insertBotherNode(a1, b2);
								root = TreeNode.getHeadNode(a1);
							}
							if (b1 != null && b2 != null) {
								if (!(b1.getFather().equals(b2.getFather()))) {
									System.out.println("�ı��߼���������");
								}
							}

						}

						if (relation.equals("үү")) { // үү��ϵ
							String k1 = s.substring(0, no[0]);
							String k2 = s.substring(no[0] + 1, no[1]);
							TreeNode gF = IoRead.search(root, k1);
							TreeNode gS = IoRead.search(root, k2);
							if (gF == null && gS == null) {
								TreeNode grandFather = new TreeNode(k1);
								TreeNode grandSon = new TreeNode(k2);
								TreeNode.insertFatherNode(grandFather, grandSon, 3);
								root = TreeNode.getHeadNode(grandFather);
							} else {
								if (gF != null && gS == null) {
									TreeNode grandSon = new TreeNode(k2);
									grandSon.setName(k2);
									TreeNode.insertFatherNode(gF, grandSon, 3);
									root = TreeNode.getHeadNode(gF);
								} else {
									if (gF == null && gS != null) {
										if (gS.getFather() == null) {
											TreeNode grandFather = new TreeNode(k1);
											grandFather.setName(k1);
											TreeNode.insertFatherNode(grandFather, gS, 3);
											root = TreeNode.getHeadNode(grandFather);
										} else {
											if (gS.getFather() != null && gS.getFather().getFather() == null) {
												TreeNode grandFather = new TreeNode(k1);
												grandFather.setName(k1);
												TreeNode.insertFatherNode(grandFather, gS.getFather(), 2);
												root = TreeNode.getHeadNode(grandFather);
											} else {
												if (gS.getFather() != null && gS.getFather().getFather() != null) {
													if (!(gS.getFather().getFather().equals(k1))) {
														System.out.println("�ı��߼���������");
													} else {
														if (gS != null && gF != null) {
															if (gS.getFather() != null
																	&& gS.getFather().getFather() == null) {
																if (gF.childlist != null) {
																	int index = 0;
																	for (TreeNode e1 : gF.getList()) {
																		if (e1.getName().equals(gS.getName())) {
																			index++;
																		}
																	}
																	if (index == 0) {
																		TreeNode.insertFatherNode(gF, gS.getFather(),
																				2);
																		root = TreeNode.getHeadNode(gF);
																	}
																} else {
																	TreeNode.insertFatherNode(gF, gS.getFather(), 2);
																	root = TreeNode.getHeadNode(gF);
																}
															}
															if (gS.getFather() != null
																	&& gS.getFather().getFather() != null) {
																if (!(gS.getFather().getFather() == gF)) {
																	System.out.println("�ı��߼�����");
																}
															}
															if (gS.getFather() == null) {
																if (gF.getList() != null) {
																	int index = 0;
																	for (TreeNode e1 : gF.getList()) {
																		for (TreeNode e2 : gF.getList()) {
																			if (e2.getName().equals(gS.getName())) {
																				index++;
																			}
																		}
																	}
																	if (index == 0) {
																		TreeNode.insertFatherNode(gF, gS, 3);
																		root = TreeNode.getHeadNode(gF);
																	}
																}
															}

														}
													}
												}
											}

										}

									}
								}
							}

						}
						if (relation.equals("����")) { // ���ӹ�ϵ
							String k2 = s.substring(0, no[0]);
							String k1 = s.substring(no[0] + 1, no[1]);
							TreeNode gF = IoRead.search(root, k1);
							TreeNode gS = IoRead.search(root, k2);
							if (gF == null && gS == null) {
								TreeNode grandFather = new TreeNode(k1);
								TreeNode grandSon = new TreeNode(k2);
								TreeNode.insertFatherNode(grandFather, grandSon, 3);
								root = TreeNode.getHeadNode(grandFather);
							} else {
								if (gF != null && gS == null) {
									TreeNode grandSon = new TreeNode(k2);
									grandSon.setName(k2);
									TreeNode.insertFatherNode(gF, grandSon, 3);
									root = TreeNode.getHeadNode(gF);
								} else {
									if (gF == null && gS != null) {
										if (gS.getFather() == null) {
											TreeNode grandFather = new TreeNode(k1);
											grandFather.setName(k1);
											TreeNode.insertFatherNode(grandFather, gS, 3);
											root = TreeNode.getHeadNode(grandFather);
										} else {
											if (gS.getFather() != null && gS.getFather().getFather() == null) {
												TreeNode grandFather = new TreeNode(k1);
												grandFather.setName(k1);
												TreeNode.insertFatherNode(grandFather, gS.getFather(), 2);
												root = TreeNode.getHeadNode(grandFather);
											} else {
												if (gS.getFather() != null && gS.getFather().getFather() != null) {
													if (!(gS.getFather().getFather().equals(k1))) {
														System.out.println("�ı��߼���������");
													} else {
														if (gS != null && gF != null) {
															if (gS.getFather() != null
																	&& gS.getFather().getFather() == null) {
																if (gF.childlist != null) {
																	int index = 0;
																	for (TreeNode e1 : gF.getList()) {
																		if (e1.getName().equals(gS.getName())) {
																			index++;
																		}
																	}
																	if (index == 0) {
																		TreeNode.insertFatherNode(gF, gS.getFather(),
																				2);
																		root = TreeNode.getHeadNode(gF);
																	}
																} else {
																	TreeNode.insertFatherNode(gF, gS.getFather(), 2);
																	root = TreeNode.getHeadNode(gF);
																}
															}
															if (gS.getFather() != null
																	&& gS.getFather().getFather() != null) {
																if (!(gS.getFather().getFather() == gF)) {
																	System.out.println("�ı��߼�����");
																}
															}
															if (gS.getFather() == null) {
																if (gF.getList() != null) {
																	int index = 0;
																	for (TreeNode e1 : gF.getList()) {
																		for (TreeNode e2 : gF.getList()) {
																			if (e2.getName().equals(gS.getName())) {
																				index++;
																			}
																		}
																	}
																	if (index == 0) {
																		TreeNode.insertFatherNode(gF, gS, 3);
																		root = TreeNode.getHeadNode(gF);
																	}
																}
															}

														}
													}
												}
											}

										}

									}
								}
							}

						}
						if (relation.equals("����")) { // ���ӹ�ϵ
							String k2 = s.substring(0, no[0]);
							String k1 = s.substring(no[0] + 1, no[1]);
							TreeNode f = IoRead.search(root, k1);
							TreeNode c = IoRead.search(root, k2);
							if (f == null && c == null) {
								TreeNode father = new TreeNode(k1);
								TreeNode son = new TreeNode(k2);
								father.setName(k1);
								son.setName(k2);
								TreeNode.insertFatherNode(father, son, 2);
								root = TreeNode.getHeadNode(father);
							}
							if (f != null && c == null) {
								TreeNode son = new TreeNode(k2);
								son.setName(k2);
								TreeNode.insertFatherNode(f, son, 2);
								root = TreeNode.getHeadNode(son);
							}
							if (f == null && c != null) {
								if (c.getFather() == null) {
									TreeNode father = new TreeNode(k1);
									father.setName(k1);
									TreeNode.insertFatherNode(father, c, 2);
									root = TreeNode.getHeadNode(father);
								} else {
									if (c.getFather().getName().equals(k1)) {
										TreeNode father = new TreeNode(k1);
										father.setName(k1);
										TreeNode.insertFatherNode(father, c, 2);
										root = TreeNode.getHeadNode(father);
									} else {
										System.out.println("�ı��߼����󣡣�");
									}
								}
							}
							if (f != null && c != null) {
								if (c.getFather() == null) {
									TreeNode father = new TreeNode(k1);
									father.setName(k1);
									TreeNode.insertFatherNode(father, c, 2);
									root = TreeNode.getHeadNode(father);
								} else {
									if (c.getFather().getName().equals(k1)) {
										TreeNode father = new TreeNode(k1);
										father.setName(k1);
										TreeNode.insertFatherNode(father, c, 2);
										root = TreeNode.getHeadNode(father);
									} else {
										System.out.println("�ı��߼����󣡣�");
									}
								}
							}
						}
					}
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println(root.getName());
	}
}

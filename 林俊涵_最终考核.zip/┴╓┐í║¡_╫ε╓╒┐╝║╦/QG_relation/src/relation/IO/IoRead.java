package relation.IO;

import relation.model.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class IoRead {
	public static String ID = null;
	public static HashSet<TStudent> readFile(int panduan) {
		HashSet<TStudent> roots = new HashSet<TStudent>();
		HashSet<TStudent> tsRoots = new HashSet<TStudent>();
		try {
			BufferedReader bw = new BufferedReader(
					new FileReader(ID));
			String s = null;
			while ((s = bw.readLine()) != null) {
				TStudent p1 = null;
				TStudent p2 = null;
				TStudent c1 = null;
				TStudent c2 = null;
				TStudent root = null;
				int[] no = new int[3];
				for (int i = 0, j = 0; i < s.length(); i++) {
					if (s.charAt(i) == '��' || s.charAt(i) == '��') { // ��¼�ļ�ĳ�е��﷨����������
						no[j] = i;
						j++;
					}
				}
				if (s.charAt(no[0]) == '��' && s.charAt(no[1]) == '��' && no[2] == 0) {
					String relation = s.substring(no[1] + 1);
					String person1 = s.substring(0, no[0]);
					String person2 = s.substring(no[0] + 1, no[1]);
					if (person1.equals(person2)) {
						System.out.print("�ı��е����ֲ����ظ�����");
						continue;
					}
					for (TStudent e : roots) {
						if (p1 == null) {
							p1 = TStudent.search(e, person1);
						}
						if (p2 == null) {
							p2 = TStudent.search(e, person2);
						}
					}
					for (TStudent e : tsRoots) {
						if (c1 == null) {
							c1 = TStudent.search(e, person1);
						}
						if (c2 == null) {
							c2 = TStudent.search(e, person2);
						}
					}
					if (relation.equals("үү")) {
						root = TStudent.insertTStudenThree(p1, p2, person1, person2);
						roots.add(root);
					}
					if (relation.equals("�ְ�")) {
						root = TStudent.insertTStudent(p1, p2, person1, person2);
						roots.add(root);
					}
					if (relation.equals("�ֵ�")) {
						root = TStudent.insertClassmates(p1, p2, person1, person2);
						roots.add(root);
					}
					if (relation.equals("����")) {
						root = TStudent.insertTStudent(p2, p1, person2, person1);
						roots.add(root);
					}
					if (relation.equals("����")) {
						root = TStudent.insertTStudenThree(p2, p1, person2, person1);
						roots.add(root);
					}
					if (relation.equals("�ܵ�")) {
						root = TStudent.insertClassmates(p1, p2, person1, person2);
						roots.add(root);
					}
					if (relation.equals("���")) {
						root = TStudent.insertClassmates(p1, p2, person1, person2);
						roots.add(root);
					}
					if (relation.equals("��ʦ")) {
						root = TStudent.insertTStudent(c1, c2, person1, person2);
						tsRoots.add(root);
					}
					if (relation.equals("ͬѧ")) {
						root = TStudent.insertClassmates(c1, c2, person1, person2);
						tsRoots.add(root);
					}
					if (relation.equals("ѧ��")) {
						root = TStudent.insertTStudent(c2, c1, person2, person1);
						tsRoots.add(root);
					}
				}
				if (s.charAt(no[0]) == '��' && s.charAt(no[1]) == '��' && no[2] == 0) {
					String relation = s.substring(no[0] + 1, no[1]);
					String person1 = s.substring(0, no[0]);
					String person2 = s.substring(no[1] + 1);
					if (person1.equals(person2)) {
						System.out.print("�ı��е����ֲ����ظ�����");
						continue;
					}
					for (TStudent e : roots) {
						if (p1 == null) {
							p1 = TStudent.search(e, person1);
						}
						if (p2 == null) {
							p2 = TStudent.search(e, person2);
						}
					}
					for (TStudent e : tsRoots) {
						if (c1 == null) {
							c1 = TStudent.search(e, person1);
						}
						if (c2 == null) {
							c2 = TStudent.search(e, person2);
						}
					}
					if (relation.equals("үү")) {
						root = TStudent.insertTStudenThree(p2, p1, person2, person1);
						roots.add(root);
					}
					if (relation.equals("�ְ�")) {
						root = TStudent.insertTStudent(p2, p1, person2, person1);
						roots.add(root);
					}
					if (relation.equals("�ֵ�")) {
						root = TStudent.insertClassmates(p1, p2, person1, person2);
						roots.add(root);
					}
					if (relation.equals("����")) {
						root = TStudent.insertTStudent(p1, p2, person1, person2);
						roots.add(root);
					}
					if (relation.equals("����")) {
						root = TStudent.insertTStudenThree(p1, p2, person1, person2);
					}
					if (relation.equals("�ܵ�")) {
						root = TStudent.insertClassmates(p1, p2, person1, person2);
						roots.add(root);
					}
					if (relation.equals("���")) {
						root = TStudent.insertClassmates(p1, p2, person1, person2);
						roots.add(root);
					}
					if (relation.equals("��ʦ")) {
						root = TStudent.insertTStudent(c2, c1, person2, person1);
						tsRoots.add(root);
					}
					if (relation.equals("ͬѧ")) {
						root = TStudent.insertClassmates(c1, c2, person1, person2);
						tsRoots.add(root);
					}
					if (relation.equals("ѧ��")) {
						root = TStudent.insertTStudent(c1, c2, person1, person2);
						tsRoots.add(root);
					}
				}
				if (s.charAt(no[0]) == '��' && s.charAt(no[1]) == '��' && no[2] != 0) {
					String relation1 = s.substring(no[0] + 1, no[1]);
					String relation2 = s.substring(no[2] + 1);
					String person1 = s.substring(0, no[0]);
					String person2 = s.substring(no[1] + 1, no[2]);
					if (person1.equals(person2)) {
						System.out.print("�ı��е����ֲ����ظ�����");
						continue;
					}
					for (TStudent e : roots) {
						if (p1 == null) {
							p1 = TStudent.search(e, person1);
						}
						if (p2 == null) {
							p2 = TStudent.search(e, person2);
						}
					}
					if (relation1.equals("үү")) {
						if (relation2.equals("үү")) {
							root = TStudent.insertCousin(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("�ְ�")) {
							root = TStudent.insertUncle(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("�ֵ�")) {
							root = TStudent.insertUncleTwo(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("����")) {
							root = TStudent.insertTStudentfour(p2, p1, person2, person1);
							roots.add(root);
						}
						if (relation2.equals("����")) {
							root = TStudent.insertTStudentfive(p2, p1, person2, person1);
							roots.add(root);
						}
						if (relation2.equals("�ܵ�")) {
							root = TStudent.insertUncleTwo(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("���")) {
							root = TStudent.insertUncleTwo(p1, p2, person1, person2);
							roots.add(root);
						}

					}
					if (relation1.equals("�ְ�")) {
						if (relation2.equals("үү")) {
							if (!(p1 != null && p2 != null && p2.getFather().getName().equals(p1.getName()))) {
								root = TStudent.insertUncle(p2, p1, person2, person1);
								roots.add(root);
							}
						}
						if (relation2.equals("�ְ�")) {
							root = TStudent.insertClassmates(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("�ֵ�")) {
							root = TStudent.insertUncle(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("����")) {
							root = TStudent.insertTStudenThree(p2, p1, person2, person1);
							roots.add(root);
						}
						if (relation2.equals("����")) {
							root = TStudent.insertTStudentfour(p2, p1, person2, person1);
							roots.add(root);
						}
						if (relation2.equals("�ܵ�")) {
							root = TStudent.insertUncle(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("���")) {
							root = TStudent.insertUncle(p1, p2, person1, person2);
							roots.add(root);
						}
					}
					if (relation1.equals("�ֵ�")) {
						if (relation2.equals("үү")) {
							root = TStudent.insertUncleTwo(p2, p1, person2, person1);
							roots.add(root);
						}
						if (relation2.equals("�ְ�")) {
							root = TStudent.insertUncle(p2, p1, person2, person1);
							roots.add(root);
						}
						if (relation2.equals("�ֵ�")) {
							root = TStudent.insertClassmates(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("����")) {
							root = TStudent.insertTStudent(p2, p1, person2, person1);
							roots.add(root);
						}
						if (relation2.equals("����")) {
							root = TStudent.insertTStudenThree(p2, p1, person2, person1);
							roots.add(root);
						}
						if (relation2.equals("�ܵ�")) {
							root = TStudent.insertClassmates(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("���")) {
							root = TStudent.insertClassmates(p1, p2, person1, person2);
							roots.add(root);
						}
					}
					if (relation1.equals("����")) {
						if (relation2.equals("үү")) {
							root = TStudent.insertTStudentfour(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("�ְ�")) {
							root = TStudent.insertTStudenThree(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("�ֵ�")) {
							root = TStudent.insertTStudent(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("����")) {
							System.out.println("�ı���䲻��Ϊ�����Ķ���Ϊ�����Ķ��ӣ���");
						}
						if (relation2.equals("����")) {
							root = TStudent.insertTStudent(p2, p1, person2, person1);
							roots.add(root);
						}
						if (relation2.equals("�ܵ�")) {
							root = TStudent.insertTStudent(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("���")) {
							root = TStudent.insertTStudent(p1, p2, person1, person2);
							roots.add(root);
						}
					}
					if (relation1.equals("����")) {
						if (relation2.equals("үү")) {
							root = TStudent.insertTStudentfive(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("�ְ�")) {
							root = TStudent.insertTStudentfour(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("�ֵ�")) {
							root = TStudent.insertTStudenThree(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("����")) {
							root = TStudent.insertTStudent(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("����")) {
							System.out.println("�ı���䲻��Ϊ����������Ϊ���������ӣ���");
						}
						if (relation2.equals("�ܵ�")) {
							root = TStudent.insertTStudenThree(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("���")) {
							root = TStudent.insertTStudenThree(p1, p2, person1, person2);
							roots.add(root);
						}
					}
					if (relation1.equals("�ܵ�")) {
						if (relation2.equals("үү")) {
							root = TStudent.insertUncleTwo(p2, p1, person2, person1);
							roots.add(root);
						}
						if (relation2.equals("�ְ�")) {
							root = TStudent.insertUncle(p2, p1, person2, person1);
							roots.add(root);
						}
						if (relation2.equals("�ֵ�")) {
							root = TStudent.insertClassmates(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("����")) {
							root = TStudent.insertTStudent(p2, p1, person2, person1);
							roots.add(root);
						}
						if (relation2.equals("����")) {
							root = TStudent.insertTStudenThree(p2, p1, person2, person1);
							roots.add(root);
						}
						if (relation2.equals("�ܵ�")) {
							root = TStudent.insertClassmates(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("���")) {
							root = TStudent.insertClassmates(p1, p2, person1, person2);
							roots.add(root);
						}
					}
					if (relation1.equals("���")) {
						if (relation2.equals("үү")) {
							root = TStudent.insertUncleTwo(p2, p1, person2, person1);
							roots.add(root);
						}
						if (relation2.equals("�ְ�")) {
							root = TStudent.insertUncle(p2, p1, person2, person1);
							roots.add(root);
						}
						if (relation2.equals("�ֵ�")) {
							root = TStudent.insertClassmates(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("����")) {
							root = TStudent.insertTStudent(p2, p1, person2, person1);
							roots.add(root);
						}
						if (relation2.equals("����")) {
							root = TStudent.insertTStudenThree(p2, p1, person2, person1);
							roots.add(root);
						}
						if (relation2.equals("�ܵ�")) {
							root = TStudent.insertClassmates(p1, p2, person1, person2);
							roots.add(root);
						}
						if (relation2.equals("���")) {
							root = TStudent.insertClassmates(p1, p2, person1, person2);
							roots.add(root);
						}
					}
					if (relation1.equals("��ʦ")) {
						if (relation2.equals("��ʦ")) {
							root = TStudent.insertClassmates(p1, p2, person1, person2);
							tsRoots.add(root);
						}
						if (relation2.equals("ͬѧ")) {
							root = TStudent.insertUncle(p1, p2, person1, person2);
							tsRoots.add(root);
						}
						if (relation2.equals("ѧ��")) {
							root = TStudent.insertTStudenThree(p2, p1, person2, person1);
							tsRoots.add(root);
						}
					}
					if (relation1.equals("ͬѧ")) {
						if (relation2.equals("��ʦ")) {
							TStudent.insertUncle(p2, p1, person2, person1);
							tsRoots.add(root);
						}
						if (relation2.equals("ͬѧ")) {
							TStudent.insertClassmates(p1, p2, person1, person2);
							tsRoots.add(root);
						}
						if (relation2.equals("ѧ��")) {
							TStudent.insertTStudent(p2, p1, person2, person1);
							tsRoots.add(root);
						}
					}
					if (relation1.equals("ѧ��")) {
						if (relation2.equals("��ʦ")) {
							TStudent.insertTStudenThree(p1, p2, person1, person2);
							tsRoots.add(root);
						}
						if (relation2.equals("ͬѧ")) {
							TStudent.insertTStudent(p1, p2, person1, person2);
							tsRoots.add(root);
						}
						if (relation2.equals("ѧ��")) {
							System.out.println("�ı��߼���������һ��ѧ��ֻ����һ����ʦ����");
						}
					}
				}
			}
			BufferedReader bs = new BufferedReader(
					new FileReader(ID));
			String l = null;
			while ((l = bs.readLine()) != null) {
				TStudent p1 = null;
				TStudent p2 = null;
				TStudent k1 = null;
				TStudent k2 = null;
				TStudent p = null;
				TStudent root = null;
				int[] no = new int[3];
				for (int i = 0, j = 0; i < l.length(); i++) {
					if (l.charAt(i) == '��' || l.charAt(i) == '��') { // ��¼�ļ�ĳ�е��﷨����������
						no[j] = i;
						j++;
					}
				}
				if (l.charAt(no[0]) == '��' && l.charAt(no[1]) == '��' && no[2] != 0) {
					String relation1 = l.substring(no[0] + 1, no[1]);
					String relation2 = l.substring(no[2] + 1);
					String person1 = l.substring(0, no[0]);
					String person2 = l.substring(no[1] + 1, no[2]);
					if (person1.equals(person2)) {
						System.out.print("�ı��е����ֲ����ظ�����");
						continue;
					}
					for (TStudent e : roots) {
						if (p1 == null) {
							p1 = TStudent.search(e, person1);
						}
					}
					for (TStudent e : tsRoots) {
						if (p2 == null) {
							p2 = TStudent.search(e, person2);
						}
					}
					for (TStudent e : tsRoots) {
						if (k1 == null) {
							k1 = TStudent.search(e, person1);
						}
					}
					for (TStudent e : roots) {
						if (k2 == null) {
							k2 = TStudent.search(e, person2);
						}
					}
					if (relation1.equals("үү")) {
						if (TStudent.isGrandFather(p1)) {
							for (TStudent e : tsRoots) {
								if (p == null) {
									p = TStudent.search(e, p1.getFather().getFather().getName());
								}
							}
							if (relation2.equals("��ʦ")) {
								root = TStudent.insertTStudent(p, p2, p1.getFather().getFather().getName(), person2);
								tsRoots.add(root);
							}
							if (relation2.equals("ͬѧ")) {
								root = TStudent.insertClassmates(p, p2, p1.getFather().getFather().getName(), person2);
								tsRoots.add(root);
							}
							if (relation2.equals("ѧ��")) {
								root = TStudent.insertTStudent(p2, p, person2, p1.getFather().getFather().getName());
								tsRoots.add(root);
							}
						} else {
							if (relation2.equals("��ʦ")) {
								if (TStudent.isFather(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, p2.getFather().getName());
										}
									}
									root = TStudent.insertTStudenThree(p, p1, p.getName(), person1);
									roots.add(root);
								}
							}
							if (relation2.equals("ͬѧ")) {
								if (TStudent.isBotherOne(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, TStudent.getBother(p2, person2).getName());
										}
									}
									root = TStudent.insertTStudenThree(p, p1, p.getName(), person1);
									roots.add(root);
								}
							}
							if (relation2.equals("ѧ��")) {
								if (TStudent.isSonOne(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, p2.getList().get(0).getName());
										}
									}
									root = TStudent.insertTStudenThree(p, p1, p.getName(), person1);
									roots.add(root);
								}
							}
						}
					}
					if (relation1.equals("�ְ�")) {
						if (TStudent.isFather(p1)) {
							for (TStudent e : tsRoots) {
								if (p == null) {
									p = TStudent.search(e, p1.getFather().getName());
								}
							}
							if (relation2.equals("��ʦ")) {
								root = TStudent.insertTStudent(p, p2, p1.getFather().getName(), person2);
								tsRoots.add(root);
							}
							if (relation2.equals("ͬѧ")) {
								root = TStudent.insertClassmates(p, p2, p1.getFather().getName(), person2);
								tsRoots.add(root);
							}
							if (relation2.equals("ѧ��")) {
								root = TStudent.insertTStudent(p2, p, person2, p1.getFather().getFather().getName());
								tsRoots.add(root);
							}
						} else {
							if (relation2.equals("��ʦ")) {
								if (TStudent.isFather(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, p2.getFather().getName());
										}
									}
									root = TStudent.insertTStudent(p, p1, p.getName(), person1);
									roots.add(root);
								}
							}
							if (relation2.equals("ͬѧ")) {
								if (TStudent.isBotherOne(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, TStudent.getBother(p2, person2).getName());
										}
									}
									root = TStudent.insertTStudent(p, p1, p.getName(), person1);
									roots.add(root);
								}
							}
							if (relation2.equals("ѧ��")) {
								if (TStudent.isSonOne(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, p2.getList().get(0).getName());
										}
									}
									root = TStudent.insertTStudent(p, p1, p.getName(), person1);
									roots.add(root);
								}
							}
						}
					}
					if (relation1.equals("�ֵ�")) {
						if (TStudent.isBotherOne(p1)) {
							TStudent b = TStudent.getBother(p1, person1);
							for (TStudent e : tsRoots) {
								if (p == null) {
									p = TStudent.search(e, b.getName());
								}
							}
							if (relation2.equals("��ʦ")) {
								root = TStudent.insertTStudent(p, p2, p.getName(), person2);
								tsRoots.add(root);
							}
							if (relation2.equals("ͬѧ")) {
								root = TStudent.insertClassmates(p, p2, p.getName(), person2);
								tsRoots.add(root);
							}
							if (relation2.equals("ѧ��")) {
								root = TStudent.insertTStudent(p2, p, person2, p.getName());
								tsRoots.add(root);
							}
						} else {
							if (relation2.equals("��ʦ")) {
								if (TStudent.isFather(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, p2.getFather().getName());
										}
									}
									root = TStudent.insertClassmates(p, p1, p.getName(), person1);
									roots.add(root);
								}
							}
							if (relation2.equals("ͬѧ")) {
								if (TStudent.isBotherOne(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, TStudent.getBother(p2, person2).getName());
										}
									}
									root = TStudent.insertClassmates(p, p1, p.getName(), person1);
									roots.add(root);
								}
							}
							if (relation2.equals("ѧ��")) {
								if (TStudent.isSonOne(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, p2.getList().get(0).getName());
										}
									}
									root = TStudent.insertClassmates(p, p1, p.getName(), person1);
									roots.add(root);
								}
							}
						}
					}
					if (relation1.equals("����")) {
						if (TStudent.isFather(p1)) {
							for (TStudent e : tsRoots) {
								if (p == null) {
									p = TStudent.search(e, p1.getList().get(0).getName());
								}
							}
							if (relation2.equals("��ʦ")) {
								root = TStudent.insertTStudent(p, p2, p1.getList().get(0).getName(), person2);
								tsRoots.add(root);
							}
							if (relation2.equals("ͬѧ")) {
								root = TStudent.insertClassmates(p, p2, p1.getList().get(0).getName(), person2);
								tsRoots.add(root);
							}
							if (relation2.equals("ѧ��")) {
								root = TStudent.insertTStudent(p2, p, person2, p1.getList().get(0).getName());
								tsRoots.add(root);
							}
						} else {
							if (relation2.equals("��ʦ")) {
								if (TStudent.isFather(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, p2.getFather().getName());
										}
									}
									root = TStudent.insertTStudent(p1, p, person1, p.getName());
									roots.add(root);
								}
							}
							if (relation2.equals("ͬѧ")) {
								if (TStudent.isBotherOne(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, TStudent.getBother(p2, person2).getName());
										}
									}
									root = TStudent.insertTStudent(p1, p, person1, p.getName());
									roots.add(root);
								}
							}
							if (relation2.equals("ѧ��")) {
								if (TStudent.isSonOne(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, p2.getList().get(0).getName());
										}
									}
									root = TStudent.insertTStudent(p1, p, person1, p.getName());
									roots.add(root);
								}
							}
						}
					}
					if (relation1.equals("����")) {
						if (TStudent.isGrandSonOne(p1)) {
							for (TStudent e : tsRoots) {
								if (p == null) {
									p = TStudent.search(e, TStudent.getGrandSon(p1).getName());
								}
							}
							if (relation2.equals("��ʦ")) {
								root = TStudent.insertTStudent(p, p2, TStudent.getGrandSon(p1).getName(), person2);
								tsRoots.add(root);
							}
							if (relation2.equals("ͬѧ")) {
								root = TStudent.insertClassmates(p, p2, TStudent.getGrandSon(p1).getName(), person2);
								tsRoots.add(root);
							}
							if (relation2.equals("ѧ��")) {
								root = TStudent.insertTStudent(p2, p, person2, TStudent.getGrandSon(p1).getName());
								tsRoots.add(root);
							}
						} else {
							if (relation2.equals("��ʦ")) {
								if (TStudent.isFather(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, p2.getFather().getName());
										}
									}
									root = TStudent.insertTStudenThree(p1, p, person1, p.getName());
									roots.add(root);
								}
							}
							if (relation2.equals("ͬѧ")) {
								if (TStudent.isBotherOne(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, TStudent.getBother(p2, person2).getName());
										}
									}
									root = TStudent.insertTStudenThree(p1, p, person1, p.getName());
									roots.add(root);
								}
							}
							if (relation2.equals("ѧ��")) {
								if (TStudent.isSonOne(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, p2.getList().get(0).getName());
										}
									}
									root = TStudent.insertTStudenThree(p1, p, person1, p.getName());
									roots.add(root);
								}
							}
						}
					}
					if (relation1.equals("�ܵ�")) {
						if (TStudent.isBotherOne(p1)) {
							TStudent b = TStudent.getBother(p1, person1);
							for (TStudent e : tsRoots) {
								if (p == null) {
									p = TStudent.search(e, b.getName());
								}
							}
							if (relation2.equals("��ʦ")) {
								root = TStudent.insertTStudent(p, p2, p.getName(), person2);
								tsRoots.add(root);
							}
							if (relation2.equals("ͬѧ")) {
								root = TStudent.insertClassmates(p, p2, p.getName(), person2);
								tsRoots.add(root);
							}
							if (relation2.equals("ѧ��")) {
								root = TStudent.insertTStudent(p2, p, person2, p.getName());
								tsRoots.add(root);
							}
						} else {
							if (relation2.equals("��ʦ")) {
								if (TStudent.isFather(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, p2.getFather().getName());
										}
									}
									root = TStudent.insertClassmates(p, p1, p.getName(), person1);
									roots.add(root);
								}
							}
							if (relation2.equals("ͬѧ")) {
								if (TStudent.isBotherOne(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, TStudent.getBother(p2, person2).getName());
										}
									}
									root = TStudent.insertClassmates(p, p1, p.getName(), person1);
									roots.add(root);
								}
							}
							if (relation2.equals("ѧ��")) {
								if (TStudent.isSonOne(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, p2.getList().get(0).getName());
										}
									}
									root = TStudent.insertClassmates(p, p1, p.getName(), person1);
									roots.add(root);
								}
							}
						}
					}
					if (relation1.equals("���")) {
						if (TStudent.isBotherOne(p1)) {
							TStudent b = TStudent.getBother(p1, person1);
							for (TStudent e : tsRoots) {
								if (p == null) {
									p = TStudent.search(e, b.getName());
								}
							}
							if (relation2.equals("��ʦ")) {
								root = TStudent.insertTStudent(p, p2, p.getName(), person2);
								tsRoots.add(root);
							}
							if (relation2.equals("ͬѧ")) {
								root = TStudent.insertClassmates(p, p2, p.getName(), person2);
								tsRoots.add(root);
							}
							if (relation2.equals("ѧ��")) {
								root = TStudent.insertTStudent(p2, p, person2, p.getName());
								tsRoots.add(root);
							}
						} else {
							if (relation2.equals("��ʦ")) {
								if (TStudent.isFather(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, p2.getFather().getName());
										}
									}
									root = TStudent.insertClassmates(p, p1, p.getName(), person1);
									roots.add(root);
								}
							}
							if (relation2.equals("ͬѧ")) {
								if (TStudent.isBotherOne(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, TStudent.getBother(p2, person2).getName());
										}
									}
									root = TStudent.insertClassmates(p, p1, p.getName(), person1);
									roots.add(root);
								}
							}
							if (relation2.equals("ѧ��")) {
								if (TStudent.isSonOne(p2)) {
									for (TStudent e : roots) {
										if (p == null) {
											p = TStudent.search(e, p2.getList().get(0).getName());
										}
									}
									root = TStudent.insertClassmates(p, p1, p.getName(), person1);
									roots.add(root);
								}
							}
						}
					}
					if (relation1.equals("��ʦ")) {
						if (TStudent.isFather(k1)) {
							for (TStudent e : roots) {
								if (p == null) {
									p = TStudent.search(e, k1.getFather().getName());
								}
							}
							if (relation2.equals("үү")) {
								root = TStudent.insertTStudenThree(p, k2, k1.getFather().getName(), person2);
								roots.add(root);
							}
							if (relation2.equals("�ְ�")) {
								root = TStudent.insertTStudent(p, k2, k1.getFather().getName(), person2);
								roots.add(root);
							}
							if (relation2.equals("�ֵ�")) {
								root = TStudent.insertClassmates(p, k2, k1.getFather().getName(), person2);
								roots.add(root);
							}
							if (relation2.equals("����")) {
								root = TStudent.insertTStudent(k2, p, person2, k1.getFather().getName());
								roots.add(root);
							}
							if (relation2.equals("����")) {
								root = TStudent.insertTStudenThree(k2, p, person2, k1.getFather().getName());
								roots.add(root);
							}
							if (relation2.equals("�ܵ�")) {
								root = TStudent.insertClassmates(p, k2, k1.getFather().getName(), person2);
								roots.add(root);
							}
							if (relation2.equals("���")) {
								root = TStudent.insertClassmates(p, k2, k1.getFather().getName(), person2);
								roots.add(root);
							}
						} else {
							if (relation2.equals("үү")) {
								if (TStudent.isGrandFather(k2)) {
									for (TStudent e : tsRoots) {
										if (p == null) {
											p = TStudent.search(e, k2.getFather().getFather().getName());
										}
									}
									root = TStudent.insertTStudent(p, k1, k2.getFather().getFather().getName(),
											person1);
									tsRoots.add(root);
								}
							}
							if (relation2.equals("�ְ�")) {
								if (TStudent.isFather(k2)) {
									for (TStudent e : tsRoots) {
										if (p == null) {
											p = TStudent.search(e, k2.getFather().getName());
										}
									}
									root = TStudent.insertTStudent(p, k1, k2.getFather().getName(), person1);
									tsRoots.add(root);
								}
							}
							if (relation2.equals("�ֵ�")) {
								if (TStudent.isBotherOne(k2)) {
									for (TStudent e : tsRoots) {
										if (p == null) {
											p = TStudent.search(e,
													TStudent.getBother(k2, person2).getFather().getName());
										}
									}
									root = TStudent.insertTStudent(p, k1,
											TStudent.getBother(k2, person2).getFather().getName(), person1);
									tsRoots.add(root);
								}
							}
							if (relation2.equals("����")) {
								if (TStudent.isSonOne(k2)) {
									for (TStudent e : tsRoots) {
										if (p == null) {
											p = TStudent.search(e, k2.getList().get(0).getName());
										}
									}
									root = TStudent.insertTStudent(p, k1,
											TStudent.getBother(k2, person2).getFather().getName(), person1);
									tsRoots.add(root);
								}
							}
							if (relation2.equals("����")) {
								if (TStudent.isGrandSonOne(k2)) {
									for (TStudent e : tsRoots) {
										if (p == null) {
											p = TStudent.search(e, TStudent.getGrandSon(k2).getName());
										}
									}
									root = TStudent.insertTStudent(p, k1, TStudent.getGrandSon(k2).getName(), person1);
									tsRoots.add(root);
								}
							}
							if (relation2.equals("�ܵ�")) {
								if (TStudent.isBotherOne(k2)) {
									for (TStudent e : tsRoots) {
										if (p == null) {
											p = TStudent.search(e,
													TStudent.getBother(k2, person2).getFather().getName());
										}
									}
									root = TStudent.insertTStudent(p, k1,
											TStudent.getBother(k2, person2).getFather().getName(), person1);
									tsRoots.add(root);
								}
							}
							if (relation2.equals("���")) {
								if (TStudent.isBotherOne(k2)) {
									for (TStudent e : tsRoots) {
										if (p == null) {
											p = TStudent.search(e,
													TStudent.getBother(k2, person2).getFather().getName());
										}
									}
									root = TStudent.insertTStudent(p, k1,
											TStudent.getBother(k2, person2).getFather().getName(), person1);
									tsRoots.add(root);
								}
							}
						}
					}
					if (relation1.equals("ͬѧ")) {
						if (TStudent.isBotherOne(k1)) {
							for (TStudent e : roots) {
								if (p == null) {
									p = TStudent.search(e, TStudent.getBother(k1, k1.getName()).getName());
								}
							}
							if (relation2.equals("үү")) {
								root = TStudent.insertTStudenThree(p, k2,
										TStudent.getBother(k1, k1.getName()).getName(), person2);
								roots.add(root);
							}
							if (relation2.equals("�ְ�")) {
								root = TStudent.insertTStudent(p, k2, TStudent.getBother(k1, k1.getName()).getName(),
										person2);
								roots.add(root);
							}
							if (relation2.equals("�ֵ�")) {
								root = TStudent.insertClassmates(p, k2, TStudent.getBother(k1, k1.getName()).getName(),
										person2);
								roots.add(root);
							}
							if (relation2.equals("����")) {
								root = TStudent.insertTStudent(k2, p, person2,
										TStudent.getBother(k1, k1.getName()).getName());
								roots.add(root);
							}
							if (relation2.equals("����")) {
								root = TStudent.insertTStudenThree(k2, p, person2,
										TStudent.getBother(k1, k1.getName()).getName());
								roots.add(root);
							}
							if (relation2.equals("�ܵ�")) {
								root = TStudent.insertClassmates(p, k2, TStudent.getBother(k1, k1.getName()).getName(),
										person2);
								roots.add(root);
							}
							if (relation2.equals("���")) {
								root = TStudent.insertClassmates(p, k2, TStudent.getBother(k1, k1.getName()).getName(),
										person2);
								roots.add(root);
							}
						} else {
							if (relation2.equals("үү")) {
								if (TStudent.isGrandFather(k2)) {
									for (TStudent e : tsRoots) {
										if (p == null) {
											p = TStudent.search(e, k2.getFather().getFather().getName());
										}
									}
									root = TStudent.insertClassmates(p, k1, k2.getFather().getFather().getName(),
											person1);
									tsRoots.add(root);
								}
							}
							if (relation2.equals("�ְ�")) {
								if (TStudent.isFather(k2)) {
									for (TStudent e : tsRoots) {
										if (p == null) {
											p = TStudent.search(e, k2.getFather().getName());
										}
									}
									root = TStudent.insertClassmates(p, k1, k2.getFather().getName(), person1);
									tsRoots.add(root);
								}
							}
							if (relation2.equals("�ֵ�")) {
								if (TStudent.isBotherOne(k2)) {
									for (TStudent e : tsRoots) {
										if (p == null) {
											p = TStudent.search(e,
													TStudent.getBother(k2, person2).getFather().getName());
										}
									}
									root = TStudent.insertClassmates(p, k1,
											TStudent.getBother(k2, person2).getFather().getName(), person1);
									tsRoots.add(root);
								}
							}
							if (relation2.equals("����")) {
								if (TStudent.isSonOne(k2)) {
									for (TStudent e : tsRoots) {
										if (p == null) {
											p = TStudent.search(e, k2.getList().get(0).getName());
										}
									}
									root = TStudent.insertClassmates(p, k1,
											TStudent.getBother(k2, person2).getFather().getName(), person1);
									tsRoots.add(root);
								}
							}
						}
						if (relation1.equals("ѧ��")) {
							if (TStudent.isSonOne(k1)) {
								for (TStudent e : roots) {
									if (p == null) {
										p = TStudent.search(e, k1.getFather().getName());
									}
								}
								if (relation2.equals("үү")) {
									root = TStudent.insertTStudenThree(p, k2, k1.getFather().getName(), person2);
									roots.add(root);
								}
								if (relation2.equals("�ְ�")) {
									root = TStudent.insertTStudent(p, k2, k1.getFather().getName(), person2);
									roots.add(root);
								}
								if (relation2.equals("�ֵ�")) {
									root = TStudent.insertClassmates(p, k2, k1.getFather().getName(), person2);
									roots.add(root);
								}
								if (relation2.equals("����")) {
									root = TStudent.insertTStudent(k2, p, person2, k1.getFather().getName());
									roots.add(root);
								}
								if (relation2.equals("����")) {
									root = TStudent.insertTStudenThree(k2, p, person2, k1.getFather().getName());
									roots.add(root);
								}
								if (relation2.equals("�ܵ�")) {
									root = TStudent.insertClassmates(p, k2, k1.getFather().getName(), person2);
									roots.add(root);
								}
								if (relation2.equals("���")) {
									root = TStudent.insertClassmates(p, k2, k1.getFather().getName(), person2);
									roots.add(root);
								}
							} else {
								if (relation2.equals("үү")) {
									if (TStudent.isGrandFather(k2)) {
										for (TStudent e : tsRoots) {
											if (p == null) {
												p = TStudent.search(e, k2.getFather().getFather().getName());
											}
										}
										root = TStudent.insertTStudent(k1, p, person1,
												k2.getFather().getFather().getName());
										tsRoots.add(root);
									}
								}
								if (relation2.equals("�ְ�")) {
									if (TStudent.isFather(k2)) {
										for (TStudent e : tsRoots) {
											if (p == null) {
												p = TStudent.search(e, k2.getFather().getName());
											}
										}
										root = TStudent.insertTStudent(k1, p, person1, k2.getFather().getName());
										tsRoots.add(root);
									}
								}
								if (relation2.equals("�ֵ�")) {
									if (TStudent.isBotherOne(k2)) {
										for (TStudent e : tsRoots) {
											if (p == null) {
												p = TStudent.search(e,
														TStudent.getBother(k2, person2).getFather().getName());
											}
										}
										root = TStudent.insertTStudent(k1, p, person1,
												TStudent.getBother(k2, person2).getFather().getName());
										tsRoots.add(root);
									}
								}
								if (relation2.equals("����")) {
									if (TStudent.isSonOne(k2)) {
										for (TStudent e : tsRoots) {
											if (p == null) {
												p = TStudent.search(e, k2.getList().get(0).getName());
											}
										}
										root = TStudent.insertTStudent(k1, p, person1,
												TStudent.getBother(k2, person2).getFather().getName());
										tsRoots.add(root);
									}
								}
								if (relation2.equals("����")) {
									if (TStudent.isGrandSonOne(k2)) {
										for (TStudent e : tsRoots) {
											if (p == null) {
												p = TStudent.search(e, TStudent.getGrandSon(k2).getName());
											}
										}
										root = TStudent.insertTStudent(k1, p, person1,
												TStudent.getGrandSon(k2).getName());
										tsRoots.add(root);
									}
								}
								if (relation2.equals("�ܵ�")) {
									if (TStudent.isBotherOne(k2)) {
										for (TStudent e : tsRoots) {
											if (p == null) {
												p = TStudent.search(e, TStudent.getBother(k2, person2).getFather().getName());
											}
										}
										root = TStudent.insertTStudent(k1, p, person1,
												TStudent.getBother(k2, person2).getFather().getName());
										tsRoots.add(root);
									}
								}
								if (relation2.equals("���")) {
									if (TStudent.isBotherOne(k2)) {
										for (TStudent e : tsRoots) {
											if (p == null) {
												p = TStudent.search(e,
														TStudent.getBother(k2, person2).getFather().getName());
											}
										}
										root = TStudent.insertTStudent(k1, p, person1,
												TStudent.getBother(k2, person2).getFather().getName());
										tsRoots.add(root);
									}
								}
							}
						}
					}
				}
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
		if (panduan == 0) {
			return roots;
		} else {
			return tsRoots;
		}
	}
	static Set<TStudent> xroots ;
	static Set<TStudent> xtsRoots ;
	String aimRelation;
	public static void fianlSearch(String c1, String c2) {
		xroots = IoRead.readFile(0);
		xtsRoots = IoRead.readFile(1);
		List<TStudent> index = new ArrayList();
		List<TStudent> index2 = new ArrayList();
		TStudent m = null;
		for (TStudent k1 : xroots) {
			if (TStudent.searchTStudent(k1) != k1) {
				index.add(k1);
			}
		}
		for (int i = 0; i < index.size(); i++) {
			xroots.remove(index.get(i));
		}
		for (TStudent k1 : xtsRoots) {
			if (TStudent.searchTStudent(k1) != k1) {
				index2.add(k1);
			}
		}
		for (int i = 0; i < index2.size(); i++) {
			xtsRoots.remove(index2.get(i));
		}
		for (TStudent e : xroots) {
			m = TStudent.search(e, c1);
			if (m != null) {
				TStudent.inquiry(m, c2);
			}
		}
		for (TStudent e : xtsRoots) {
			m = TStudent.search(e, c1);
			if (m != null) {
				TStudent.inquiryTs(m, c2);
			}
		}
	}
}

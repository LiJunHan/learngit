package relation.model;

import java.util.ArrayList;

import relation.IO.IoRead;
import relation.view.LoginUi;

public class TStudent {
	private String name;
	private TStudent fteacher;
	public ArrayList<TStudent> Students = new ArrayList<TStudent>();

	/**
	 * ����һ�����췽��
	 * 
	 * @param e
	 * @return
	 */

	public void TStudent(String k) {
		this.name = k;
	}

	public String getName() {
		return name;
	}

	public TStudent getFather() {
		return fteacher;
	}

	public ArrayList<TStudent> getList() {
		return Students;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setFather(TStudent father) {
		this.fteacher = father;
	}

	public void setStudents(TStudent e) {
		Students.add(e);
	}

	public static TStudent searchTStudent(TStudent e) {
		while (e.fteacher != null) {
			e = e.fteacher;
		}
		return e;
	}
	/**
	 * �鿴Ŀ��ڵ�
	 * 
	 * @param root
	 * @param aimName
	 * @return
	 */
	public static TStudent search(TStudent root, String aimName) {
		TStudent aim;
		if (root != null) {
			if (root.getName().equals(aimName)) {
				aim = root;
				return aim;
			} else {
				for (TStudent k : root.Students) {
					if (k.getName().equals(aimName)) {
						aim = k;
						return aim;
					} else {
						TStudent o = search(k, aimName);
						if (o != null) {
							return o;
						}
					}
				}
			}
		}
		return null;
	}

	/**
	 * ���븸�ӡ�ʦ����ϵ
	 * 
	 * @param teacher
	 * @param student
	 * @param k1
	 * @param k2
	 * @return
	 */
	public static TStudent insertTStudent(TStudent teacher, TStudent student, String k1, String k2) {
		if ((teacher == null) && (student == null)) {
			TStudent t = new TStudent();
			t.setName(k1);
			TStudent s = new TStudent();
			s.setName(k2);
			t.getList().add(s);
			s.fteacher = t;
			return t;
		} else {
			if (teacher != null && student == null) {
				TStudent s = new TStudent();
				s.setName(k2);
				teacher.getList().add(s);
				s.setFather(teacher);
				TStudent root = TStudent.searchTStudent(teacher);
				return root;
			} else {
				if (teacher == null && student != null) {
					if (student.fteacher != null) {
						if (student.fteacher.getName().equals("��")) {
							student.fteacher.setName(k1);
							return TStudent.searchTStudent(student);
						} else {
							System.out.println("ST�ı��߼���������");
						}
					} else {
						TStudent t = new TStudent();
						t.setName(k1);
						t.getList().add(student);
						student.fteacher = t;
						TStudent root = TStudent.searchTStudent(student);
						return root;
					}
				} else {
					if (student.fteacher != null) {
						if (!(student.getFather().getName().equals(teacher.getName()))) {
							if (student.fteacher.getName().equals("��")) {
								student.fteacher = teacher;
								teacher.getList().add(student);
								return TStudent.searchTStudent(student);
							} else {
								System.out.println("ST�ı��߼����󣡣�");
							}
						}
					} else {
						student.setFather(teacher);
						teacher.getList().add(student);
						TStudent root = TStudent.searchTStudent(student);
						return root;
					}
				}
			}
		}
		return null;
	}

	/**
	 * ����ͬ����ϵ��ϵ
	 * 
	 * @param student1
	 * @param student2
	 * @param k1
	 * @param k2
	 * @return
	 */
	public static TStudent insertClassmates(TStudent student1, TStudent student2, String k1, String k2) {
		if (student1 == null && student2 == null) {
			TStudent t = new TStudent();
			t.setName("��");
			TStudent s1 = new TStudent();
			s1.setName(k1);
			TStudent s2 = new TStudent();
			s2.setName(k2);
			s1.setFather(t);
			s2.setFather(t);
			t.Students.add(s1);
			t.Students.add(s2);
			return t;
		} else {
			if (student1 != null && student2 == null) {
				if (student1.getFather() != null) {
					TStudent s2 = new TStudent();
					s2.setName(k2);
					TStudent root = TStudent.insertTStudent(student1.fteacher, s2, student1.fteacher.getName(), k2);
					return root;
				} else {
					TStudent t = new TStudent();
					t.setName("��");
					TStudent s2 = new TStudent();
					s2.setName(k2);
					TStudent root = TStudent.insertTStudent(t, s2, "��", k2);
					root = TStudent.insertTStudent(t, student1, "��", k1);
					return root;
				}
			} else {
				if (student1 == null && student2 != null) {
					if (student2.getFather() != null) {
						TStudent s1 = new TStudent();
						s1.setName(k1);
						TStudent root = TStudent.insertTStudent(student2.fteacher, s1, k1, k2);
						return root;
					} else {
						TStudent t = new TStudent();
						t.setName("��");
						TStudent s1 = new TStudent();
						s1.setName(k1);
						TStudent root = TStudent.insertTStudent(t, s1, "��", k1);
						root = TStudent.insertTStudent(t, student2, "��", k2);
						return root;
					}
				} else {
					if (student1.getFather() != null && student2.getFather() != null) {
						if (!(student1.getFather().getName().equals(student2.getFather().getName()))) {
							System.out.println("�ı��߼���������");
						} else {
							if (student1.getFather().getName().equals("��")) {
								student1.setFather(student2.getFather());
							}
						}
					} else {
						if (student1.getFather() != null && student2.getFather() == null) {
							TStudent root = TStudent.insertTStudent(student1.getFather(), student2, k1, k2);
							return root;
						} else {
							if (student1.getFather() == null && student2.getFather() != null) {
								TStudent root = TStudent.insertTStudent(student2.getFather(), student1, k1, k2);
								return root;
							} else {
								TStudent t = new TStudent();
								t.setName("��");
								TStudent root = TStudent.insertTStudent(t, student1, "��", k2);
								root = TStudent.insertTStudent(t, student2, "��", k2);
								return root;
							}
						}
					}
				}
			}
		}
		return null;
	}

	/**
	 * �������������ӹ�ϵ
	 * 
	 * @param args
	 */
	public static TStudent insertTStudenThree(TStudent grandFather, TStudent grandSon, String k1, String k2) {
		if (grandSon != null) {
			if (grandSon.fteacher != null) {
				TStudent root = TStudent.insertTStudent(grandFather, grandSon.fteacher, k1, null);
				return root;
			} else {
				TStudent o = new TStudent();
				o.setName("��");
				TStudent.insertTStudent(o, grandSon, null, k2);
				TStudent root = TStudent.insertTStudent(grandFather, o, k1, null);
				return root;
			}
		} else {
			TStudent o = new TStudent();
			o.setName("��");
			TStudent.insertTStudent(o, grandSon, null, k2);
			TStudent root = TStudent.insertTStudent(grandFather, o, k1, null);
			return root;
		}
	}

	/**
	 * �����Ĵ���ϵ
	 * 
	 * @param args
	 */
	public static TStudent insertTStudentfour(TStudent father, TStudent son, String k1, String k2) {
		if (son != null) {
			if (son.fteacher != null) {
				TStudent root = TStudent.insertTStudenThree(father, son.fteacher, k1, null);
				return root;
			} else {
				TStudent o = new TStudent();
				o.setName("��");
				TStudent.insertTStudent(o, son, null, k2);
				TStudent root = TStudent.insertTStudenThree(father, o, k1, null);
				return root;
			}
		} else {
			TStudent o = new TStudent();
			o.setName("��");
			TStudent.insertTStudent(o, son, null, k2);
			TStudent root = TStudent.insertTStudenThree(father, o, k1, null);
			return root;
		}
	}

	/**
	 * ���������ϵ
	 * 
	 * @param args
	 */
	public static TStudent insertTStudentfive(TStudent father, TStudent son, String k1, String k2) {
		if (son != null) {
			if (son.fteacher != null) {
				TStudent root = TStudent.insertTStudenThree(father, son.fteacher, k1, null);
				return root;
			} else {
				TStudent o = new TStudent();
				o.setName("��");
				TStudent.insertTStudent(o, son, null, k2);
				TStudent root = TStudent.insertTStudenThree(father, o, k1, null);
				return root;
			}
		} else {
			TStudent o = new TStudent();
			o.setName("��");
			TStudent.insertTStudent(o, son, null, k2);
			TStudent root = TStudent.insertTStudenThree(father, o, k1, null);
			return root;
		}
	}

	/**
	 * �����岮��ϵ
	 * 
	 * @param args
	 */
	public static TStudent insertUncle(TStudent nephew, TStudent uncle, String k1, String k2) {
		if (nephew == null && uncle == null) {
			TStudent n = new TStudent();
			n.setName(k1);
			TStudent u = new TStudent();
			u.setName(k2);
			TStudent o = new TStudent();
			o.setName("��");
			TStudent.insertTStudent(o, n, null, k1);
			TStudent root = TStudent.insertClassmates(o, u, null, k2);
			return root;
		} else {
			if (nephew == null && uncle != null) {
				if (uncle.fteacher != null) {
					TStudent n = new TStudent();
					n.setName(k1);
					return TStudent.insertTStudenThree(uncle.fteacher, n, k1, k2);
				} else {
					TStudent n = new TStudent();
					n.setName(k1);
					TStudent o = new TStudent();
					o.setName("��");
					TStudent.insertTStudent(o, uncle, null, k2);
					return TStudent.insertTStudenThree(o, n, null, k1);
				}
			} else {
				if (nephew != null && uncle == null) {
					if (nephew.fteacher == null) {
						TStudent u = new TStudent();
						u.setName(k2);
						TStudent o = new TStudent();
						o.setName("��");
						TStudent.insertTStudent(o, nephew, null, k1);
						return TStudent.insertClassmates(o, u, null, k2);
					} else {
						TStudent u = new TStudent();
						u.setName(k2);
						return TStudent.insertClassmates(nephew.fteacher, u, null, k2);
					}
				} else {
					if (nephew.fteacher == null) {
						TStudent o = new TStudent();
						o.setName("��");
						TStudent.insertTStudent(o, nephew, null, k1);
						return TStudent.insertClassmates(o, uncle, null, k2);
					} else {
						return TStudent.insertClassmates(nephew.fteacher, uncle, null, null);
					}
				}
			}
		}
	}

	/**
	 * �����幫��ϵ
	 * 
	 * @param nephew
	 * @param uncle
	 * @param k1
	 * @param k2
	 * @return
	 */
	public static TStudent insertUncleTwo(TStudent nephew, TStudent uncle, String k1, String k2) {
		if (nephew == null && uncle == null) {
			TStudent n = new TStudent();
			n.setName(k1);
			TStudent u = new TStudent();
			u.setName(k2);
			TStudent o = new TStudent();
			o.setName("��");
			TStudent.insertTStudent(o, u, null, k2);
			return TStudent.insertTStudentfour(o, nephew, null, k1);
		} else {
			if (nephew == null && uncle != null) {
				TStudent n = new TStudent();
				n.setName(k1);
				if (uncle.fteacher != null) {
					return TStudent.insertTStudentfour(uncle.fteacher, n, null, k1);
				} else {
					TStudent o = new TStudent();
					o.setName("��");
					TStudent.insertTStudent(o, uncle, null, k2);
					return TStudent.insertTStudentfour(o, nephew, null, k1);
				}
			} else {
				if (nephew != null && uncle == null) {
					TStudent u = new TStudent();
					u.setName(k2);
					if (nephew.fteacher != null) {
						if (nephew.fteacher.fteacher != null) {
							return TStudent.insertClassmates(nephew.fteacher.fteacher, u, null, k2);
						} else {
							TStudent o = new TStudent();
							o.setName("��");
							TStudent.insertTStudent(o, nephew.fteacher, null, k1);
							return TStudent.insertClassmates(o, u, null, k2);
						}
					} else {
						TStudent o = new TStudent();
						o.setName("��");
						TStudent.insertTStudenThree(o, nephew, null, k1);
						return TStudent.insertClassmates(o, u, null, k2);
					}
				} else {
					if (uncle.fteacher != null) {
						return TStudent.insertTStudentfour(uncle.fteacher, nephew, k2, k1);
					} else {
						TStudent o = new TStudent();
						o.setName("��");
						TStudent.insertTStudent(o, uncle, null, k2);
						return TStudent.insertTStudentfour(o, nephew, null, k1);
					}
				}
			}
		}
	}

	/**
	 * �������ֵܹ�ϵ
	 * 
	 * @param args
	 */
	public static TStudent insertCousin(TStudent student1, TStudent student2, String k1, String k2) {
		if (student1 == null && student2 == null) {
			TStudent s1 = new TStudent();
			s1.setName(k1);
			TStudent s2 = new TStudent();
			s2.setName(k2);
			TStudent o = new TStudent();
			o.setName("��");
			TStudent.insertTStudenThree(o, s1, null, k1);
			TStudent.insertTStudenThree(o, s2, null, k2);
			return TStudent.searchTStudent(o);
		} else {
			if (student1 != null && student2 == null) {
				TStudent s2 = new TStudent();
				s2.setName(k2);
				if (student1.fteacher != null) {
					if (student1.fteacher.fteacher != null) {
						return TStudent.insertTStudenThree(student1.fteacher.fteacher, s2, null, k2);
					} else {
						TStudent o = new TStudent();
						o.setName("��");
						TStudent.insertTStudent(o, student1, null, k1);
						TStudent.insertTStudenThree(o, s2, null, k2);
						return TStudent.searchTStudent(student1);
					}
				} else {
					TStudent o = new TStudent();
					o.setName("��");
					TStudent.insertTStudent(o, student1, null, k1);
					TStudent.insertTStudenThree(o, s2, null, k2);
					return TStudent.searchTStudent(student1);
				}
			} else {
				if (student1 == null && student2 != null) {
					TStudent s1 = new TStudent();
					s1.setName(k1);
					if (student2.fteacher != null) {
						if (student2.fteacher.fteacher != null) {
							return TStudent.insertTStudenThree(student2.fteacher.fteacher, s1, null, k1);
						} else {
							TStudent o = new TStudent();
							o.setName("��");
							TStudent.insertTStudent(o, student2, null, k2);
							TStudent.insertTStudenThree(o, s1, null, k1);
							return TStudent.searchTStudent(student2);
						}
					} else {
						TStudent o = new TStudent();
						o.setName("��");
						TStudent.insertTStudent(o, student2, null, k2);
						TStudent.insertTStudenThree(o, s1, null, k1);
						return TStudent.searchTStudent(student2);
					}
				} else {
					if (student1.fteacher == null && student2.fteacher == null) {
						TStudent o = new TStudent();
						o.setName("��");
						TStudent.insertTStudenThree(o, student1, null, k1);
						TStudent.insertTStudent(o, student2, null, k2);
						return TStudent.searchTStudent(student1);
					} else {
						if (student1.fteacher != null && student2.fteacher == null) {
							TStudent o = new TStudent();
							o.setName("��");
							TStudent.insertTStudent(o, student2, null, k2);
							TStudent.insertClassmates(o, student1.fteacher, null, null);
							return TStudent.searchTStudent(student1);
						} else {
							if (student1.fteacher == null && student2.fteacher != null) {
								TStudent o = new TStudent();
								o.setName("��");
								TStudent.insertTStudent(o, student1, null, k1);
								TStudent.insertClassmates(o, student2.fteacher, null, null);
								return TStudent.searchTStudent(student2);
							} else {
								return TStudent.insertClassmates(student1.fteacher, student2.fteacher, null, null);
							}
						}
					}
				}
			}
		}
	}

	/**
	 * �жϸýڵ��Ƿ���ȷ���ĸ��״���
	 * 
	 * @param args
	 */
	public static boolean isFather(TStudent e) {
		if (e != null) {
			if (e.fteacher != null) {
				if (!(e.fteacher.getName().equals("��"))) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	/**
	 * �жϸýڵ��Ƿ���ȷ����үү����
	 * 
	 * @param args
	 */
	public static boolean isGrandFather(TStudent e) {
		if (e != null) {
			if (e.fteacher != null) {
				if (e.fteacher.fteacher != null) {
					if (!(e.fteacher.getName().equals("��"))) {
						return true;
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	/**
	 * �жϸýڵ�Ķ���ʱ��Ψһ
	 * 
	 * @param args
	 */
	public static boolean isSonOne(TStudent e) {
		if (e != null) {
			if (e.getList().size() == 1) {
				if (e.getList().get(0).equals("��")) {
					return false;
				} else {
					return true;
				}
			} else {
				return false;
			}
		} else {
			return false;
		}

	}

	/**
	 * �жϸýڵ�������Ƿ�Ψһ
	 */
	public static boolean isGrandSonOne(TStudent e) {
		if (e != null) {
			if (e.getList().size() != 0) {
				int index = 0;
				for (TStudent k1 : e.getList()) {
					if (k1.getList().size() != 0) {
						for (TStudent k2 : e.getList()) {
							if (k2.name != null && k2.name != "��") {
								index = index + 1;
							}
						}
					}
				}
				if (index == 1) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	/**
	 * �жϸýڵ���ֵ��Ƿ�Ψһ
	 * 
	 * @param args
	 */
	public static boolean isBotherOne(TStudent e) {
		if (e != null) {
			if (e.fteacher != null) {
				if (e.fteacher.getList().size() == 2) {
					int i = 0;
					for (TStudent k : e.fteacher.getList()) {
						if (k.getName().equals("��")) {
							i = i + 1;
						}
					}
					if (i == 0) {
						return true;
					} else {
						return false;
					}
				} else {
					return false;
				}
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	/**
	 * �ҳ��ýڵ��Ψһ�ֵ�
	 * 
	 * @param args
	 */
	public static TStudent getBother(TStudent e, String b) {
		for (TStudent k : e.getFather().getList()) {
			if (!(k.getName().equals(b))) {
				return k;
			}
		}
		return null;
	}

	/**
	 * ��ȡ�ýڵ��Ψһ����
	 * 
	 * @param args
	 */
	public static TStudent getGrandSon(TStudent e) {
		TStudent root;
		for (TStudent k1 : e.getList()) {
			for (TStudent k2 : k1.getList()) {
				if (k2.getName() != null && k2.getName() != "��") {
					root = k2;
					return root;
				}
			}
		}
		return null;
	}

	/**
	 * ��ѯ����
	 * 
	 * @param args
	 */
	public static void inquiry(TStudent e, String aimName) {
		if (TStudent.isFather(e)) {
			if (e.getFather().getName().equals(aimName)) {
				String str = e.getName() + "�İְ���" + e.getFather().getName();
				LoginUi.aimRelations = str;
			}
		}
		if (TStudent.isGrandFather(e)) {
			if (e.getFather().getFather().getName().equals(aimName)) {
				String str = e.getName() + "��үү��" + e.getFather().getFather().getName();
				LoginUi.aimRelations = str;
			}
		}
		if (e.getList().size() != 0) {
			for (TStudent k : e.getList()) {
				if (k.getName().equals(aimName)) {
					String str = e.getName() + "�Ķ�����" + k.getName();
					LoginUi.aimRelations = str;
				}
			}
		}
		if (e.getList().size() != 0) {
			for (TStudent k : e.getList()) {
				if (k.getList().size() != 0) {
					for (TStudent p : k.getList()) {
						if (p.getName().equals(aimName)) {
							String str = e.getName() + "��������" + p.getName();
							LoginUi.aimRelations = str;
						}
					}
				}
			}
		}
		if (TStudent.isFather(e)) {
			if (e.fteacher.getList().size() >= 1) {
				for (TStudent k : e.fteacher.getList()) {
					if (!(k.getName().equals(e.getName())) && k.getName().equals(aimName)) {
						String str = e.getName() + "���ֵ���" + k.getName();
						LoginUi.aimRelations = str;
					}
				}
			}
		}
		if (TStudent.isGrandFather(e)) {
			if (e.getFather().getFather().getList().size() >= 1) {
				for (TStudent k : e.getFather().getFather().getList()) {
					for (TStudent p : k.getList()) {
						if (p.getName().equals(aimName) && !(p.getName().equals(e.getName()))) {
							String str = e.getName() + "�����ֵ���" + p.getName();
							LoginUi.aimRelations = str;
						}
					}
				}
			}
		}
	}

	/**
	 * �鿴ʦ����ϵ
	 * 
	 * @param args
	 */
	public static void inquiryTs(TStudent e, String aimName) {
		if (TStudent.isFather(e)) {
			if (e.getFather().getName().equals(aimName)) {
				String str = e.getName() + "����ʦ��" + e.getFather().getName();
				LoginUi.aimRelations2 = str;
			}
		}
		if (e.getList().size() != 0) {
			for (TStudent k : e.getList()) {
				if (k.getName().equals(aimName)) {
					String str = e.getName() + "��ѧ����" + k.getName();
					LoginUi.aimRelations2 = str;
				}
			}
		}
		if (TStudent.isFather(e)) {
			if (e.fteacher.getList().size() >= 1) {
				for (TStudent k : e.fteacher.getList()) {
					if (!(k.getName().equals(e.getName())) && k.getName().equals(aimName)) {
						String str = e.getName() + "��ͬѧ��" + k.getName();
						LoginUi.aimRelations2 = str;
					}
				}
			}
		}
	}
	/**
	 * ɾ�����ӹ�ϵ
	 * @param k
	 * @param l
	 */
	public static void delectFather(TStudent father, TStudent son) {
		if(father != null && son != null) {
			if(son.getFather() != null ) {
				for(TStudent e : father.getList()) {
					int index = 0;
					if(e.getName().equals(son.getName())) {
						son.fteacher = null;
						father.getList().remove(index);
						index++;
					}
				}
			}
		}
	}
	/**
	 * ɾ��ү���ϵ
	 * @param k1
	 * @param k2
	 */
	public static void delectGrandFather(TStudent grandFather, TStudent grandSon) {
		if(grandFather != null && grandSon != null) {
			if(grandSon.fteacher != null) {
				
			}
		}
	}
	
	/*
	 * ɾ�����߹�ϵ
	 */
	public static void delectTStudent(String k1, String k2) {
		for (TStudent p1 : IoRead.roots) {
			TStudent n = TStudent.search(p1, k1);
			TStudent m = TStudent.search(p1, k2);
			if(n != null && m != null) {
				
			}
		}
		for (TStudent p2 : IoRead.roots) {

		}
	}

	public static void main(String[] args) {
		TStudent k = new TStudent();
		k.setName("�ֿ���");
		TStudent s = new TStudent();
		s.setName("С��");
		TStudent g = new TStudent();
		TStudent o = new TStudent();
		o.setName("��");
		g.setName("С��");
		TStudent.insertTStudent(k, s, "�ֿ���", "С��");
		/*
		 * TStudent o = new TStudent(); o.setName("��"); o.getList().add(g);
		 * g.setFather(o);
		 */
		String k2 = "���ȵ���";
		boolean u = TStudent.isFather(s);
		System.out.println(u);
	}
}

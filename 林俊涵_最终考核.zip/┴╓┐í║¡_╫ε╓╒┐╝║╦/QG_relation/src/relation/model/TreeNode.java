package relation.model;

import java.util.*;

import relation.dao.PeopleDao;
import relation.main.IoRead;

public class TreeNode {
	private String name;
	private TreeNode father; // �ڵ���Ϣ���������֣��Լ����׵Ľڵ㣬�Ӽ��ϣ�
	public ArrayList<TreeNode> childlist = new ArrayList<TreeNode>();

	/**
	 * �������췽��
	 * 
	 * @param name
	 */
	public TreeNode(String name) {
		this.name = name;
	}

	public TreeNode(String name, TreeNode father) {
		this.name = name;
		this.father = father;
	}

	public TreeNode(String name, TreeNode father, ArrayList<TreeNode> childlist) {
		this.name = name;
		this.father = father;
		this.childlist = childlist;
	}

	/**
	 * ���ַ���
	 * 
	 */
	public String getName() { // ��ȡ����
		return name;
	}

	public TreeNode getFather() { // ��ȡ���ڵ�
		return father;
	}

	public void setName(String name) { // ���ýڵ�����
		this.name = name;
	}

	public void setFather(TreeNode father) { // ���ø��ڵ�
		this.father = father;
	}

	public ArrayList<TreeNode> getList() {
		return childlist;
	}

	/**
	 * //����һ���ڵ㣬����������
	 * 
	 * @param name
	 * @return
	 */
	public static TreeNode creatNode(String name) {
		TreeNode s = new TreeNode(name);
		return s;
	}

	/**
	 * //����ֱϵ��ϵ���������������ġ����֮��Ĺ�ϵ��
	 * 
	 * @param father
	 * @param son
	 */
	public static void insertFatherNode(TreeNode father, TreeNode son, int generations) {
		if (generations == 2) { // ��������Ŀ��ڵ�
			father.childlist.add(son);
			son.father = father;
		}
		if (generations == 3) { // ������Ŀ��ڵ�֮�����һ���ڵ�
			TreeNode n1 = new TreeNode("��");
			father.childlist.add(n1);
			n1.father = father;
			n1.childlist.add(son);
			son.father = n1;
		}
		if (generations == 4) { // ������Ŀ��ڵ�֮����������սڵ�
			TreeNode n1 = new TreeNode("��");
			TreeNode n2 = new TreeNode("��");
			father.childlist.add(n1);
			n1.father = father;
			n1.childlist.add(n2);
			n2.father = n1;
			n2.childlist.add(son);
			son.father = n2;
		}
		if (generations == 5) { // ������Ŀ��ڵ�֮����������սڵ�
			TreeNode n1 = new TreeNode("��");
			TreeNode n2 = new TreeNode("��");
			TreeNode n3 = new TreeNode("��");
			father.childlist.add(n1);
			n1.father = father;
			n1.childlist.add(n2);
			n2.father = n1;
			n2.childlist.add(n3);
			n3.father = n2;
			n3.childlist.add(son);
			son.father = n3;
		}

	}

	/**
	 * //�����ӹ�ϵ�������ڵ���������
	 * 
	 * @param grandSon
	 * @param grandFather
	 */
	public static void insertGrandFatherNode(TreeNode grandSon, TreeNode grandFather) {
		TreeNode medi = new TreeNode("��");
		grandSon.father = medi;
		grandFather.childlist.add(medi);
		medi.childlist.add(grandSon);
	}

	/**
	 * //���ֵܽڵ���������
	 * 
	 * @param a
	 * @param b
	 */
	public static void insertBotherNode(TreeNode a, TreeNode b) {
		if ((a.father == null) && (b.father == null)) {
			TreeNode medi = new TreeNode("��");
			medi.childlist.add(a);
			medi.childlist.add(b);
		} else {
			if ((a.father != null) && (b.father == null)) {
				b.father = a.father;
			} else {
				if ((a.father == null) && (b.father != null)) {
					a.father = b.father;
				} else {
					if (a.father != b.father) {
						System.out.println("�ı��߼�������");
					}
				}
			}
		}
	}

	/**
	 * //��ȡ����ڵ�ĸ��ڵ�
	 * 
	 * @param e
	 * @return
	 */
	public static TreeNode getHeadNode(TreeNode e) {
		while (e.father != null) {
			e = e.father;
		}
		return e;
	}

	/**
	 * �������ֵ�֮��Ĺ�ϵ
	 * 
	 * @param a
	 * @param b
	 */
	public static void cousinNode(TreeNode a, TreeNode b) {
		if ((a.father == null) && (b.father == null)) {
			TreeNode n1 = new TreeNode("��");
			TreeNode n2 = new TreeNode("��");
			TreeNode n3 = new TreeNode("��");
			a.father = n2;
			b.father = n3;
			n2.childlist.add(a);
			n3.childlist.add(b);
			n2.father = n1;
			n3.father = n1;
			n1.childlist.add(n2);
			n1.childlist.add(n3);
		} else {
			if ((a.father != null) && (a.father.father == null) && (b.father == null)) {
				TreeNode n1 = new TreeNode("��");
				TreeNode n2 = new TreeNode("��");
				a.father.father = n1;
				n1.childlist.add(a.father);
				n1.childlist.add(n2);
				n2.father = n1;
				n2.childlist.add(b);
				b.father = n2;
			} else {
				if ((b.father != null) && (b.father.father == null) && (a.father == null)) {
					TreeNode n1 = new TreeNode("��");
					TreeNode n2 = new TreeNode("��");
					b.father.father = n1;
					n1.childlist.add(b.father);
					n1.childlist.add(n2);
					n2.father = n1;
					n2.childlist.add(a);
					a.father = n2;
				} else {
					if (a.father.father != null && b.father == null) {
						TreeNode n1 = new TreeNode("��");
						n1.father = a.father.father;
						n1.childlist.add(b);
					} else {
						if (b.father.father != null && a.father == null) {
							TreeNode n1 = new TreeNode("��");
							n1.father = b.father.father;
							n1.childlist.add(a);
						} else {
							if (a.father.father != null && b.father.father != null
									&& a.father.father == b.father.father) {
								System.out.println("�ù�ϵ�Ѿ����ڣ���");
							} else {
								if (a.father.father != null && b.father.father != null
										&& a.father.father != b.father.father) {
									System.out.println("�ù�ϵ���ڴ���");
								}
							}

						}

					}

				}

			}

		}

	}

	/**
	 * ������Ĳ��ҷ���
	 * 
	 * @param args
	 */

	public static void main(String[] args) {
		TreeNode k = new TreeNode("�ֿ���");
		TreeNode f = new TreeNode("��ϲ��");
		TreeNode h = new TreeNode("�ֱ�");
		TreeNode.insertFatherNode(h, f, 2);
		TreeNode.insertFatherNode(f, k, 2);
		System.out.println(f.childlist.get(0).getName());
		ArrayList<TreeNode> A = new ArrayList();
		A.add(k);
		System.out.println(A.get(0).getFather().getName());
		TreeNode aim = IoRead.search(h, "�ֿ���");
		System.out.println(aim.getFather().getName());
		TreeNode root = TreeNode.getHeadNode(k);
		System.out.println(root.getName());
	}
	/**
	 * ������ϵ
	 */
	public static TStudent insertTStudenThree(TStudent grandFather, TStudent grandSon, String k1, String k2) {
		if (grandFather == null && grandSon == null) {
			TStudent f = new TStudent();
			f.setName(k1);
			TStudent s = new TStudent();
			s.setName(k2);
			TStudent o = new TStudent();
			o.setName("��");
			TStudent.insertTStudent(f, o, k1, "��");
			TStudent root = TStudent.insertTStudent(o, s, "��", k2);
			return root;
		} else {
			if (grandFather != null && grandSon == null) {
				TStudent s = new TStudent();
				s.setName(k2);
				TStudent o = new TStudent();
				o.setName("��");
				TStudent.insertTStudent(grandFather, o, k1, "��");
				TStudent root = TStudent.insertTStudent(o, s, "��", k2);
				return root;
			} else {
				if (grandFather == null && grandSon != null) {
					if (grandSon.fteacher == null) {
						TStudent o = new TStudent();
						o.setName("��");
						TStudent.insertTStudent(o, grandSon, "��", k2);
						TStudent root = TStudent.insertTStudent(grandFather, o, k1, "��");
						return root;
					} else {
						TStudent root = TStudent.insertTStudent(grandFather, grandSon.fteacher, k1, "��");
						return root;
					}
				}else {
					if(grandSon.fteacher == null) {
						TStudent o = new TStudent();
						o.setName("��");
						TStudent.insertTStudent(o, grandSon, "��", k2);
						TStudent root = TStudent.insertTStudent(grandFather, o, k1, "��");
						return 
					}
				}
			}
		}
	}
}

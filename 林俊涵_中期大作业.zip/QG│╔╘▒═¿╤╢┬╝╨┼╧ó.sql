/*
SQLyog Ultimate v11.33 (64 bit)
MySQL - 5.1.49-community : Database - addresslist
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`addresslist` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `addresslist`;

/*Table structure for table `member` */

DROP TABLE IF EXISTS `member`;

CREATE TABLE `member` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `group` varchar(30) DEFAULT NULL,
  `clas` varchar(30) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `dormitory` varchar(10) DEFAULT NULL,
  `address` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

/*Data for the table `member` */

insert  into `member`(`id`,`name`,`group`,`clas`,`phone`,`email`,`dormitory`,`address`) values (1,'林俊涵','信息安全','17级','15521093428','m15521093428@163.com','西一732','无'),(2,'ldiej','feewfwe','ffewfew','夫为恶','份额无法','份额无法','份额无法'),(5,'fewf','fwefw','fwefwe','fwefw','ewfew','fewf','fewfew'),(6,'fewf','few','wfwef','fewfwef','fewf','fwefew','fwef'),(7,'353','4234324322','97','42343824','32200','23','6565'),(10,'卡卡罗特','龟仙派','878978','897987','9798','797','987'),(12,'柯南','小学一年级','一','8484','84','84','484'),(13,'本-西蒙斯','NBA','一年级','54984984','98498','4894','89'),(14,'米切尔','NBA','一年级','489','4984','984','94'),(15,'钢铁侠','妇联','N','5598','4','49','49');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` varchar(15) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `suoyin` int(10) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`suoyin`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

/*Data for the table `user` */

insert  into `user`(`id`,`password`,`suoyin`) values ('311705279','c5dc34',3),('311705278','c5dc34',4),('311705278','123',5),('3117005278','753951',6),('3117005278','789456123',7),(NULL,'',8),('3117005279','789456123',9),('3117005254','789456123',10),('3117005269','123456789',11);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

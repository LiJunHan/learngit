package com.LinJunhan.dao;
import com.LinJunhan.model.*;
import com.LinJunhan.util.*;
import java.util.*;
import java.sql.*;

public class memberDAO {
	/**
	 * �÷��������ݿ��е�������ȡ����
	 * 
	 * @return
	 */
	public ArrayList<member> getList() {// ������ѯ
		ArrayList<member> ar = new ArrayList<member>();
		Connection conn = BaseConnection.getConnection();		
		PreparedStatement ps = null;		
		ResultSet rs = null;
		try {
			String sql = "select * from member";
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				member ne = new member();
				ne.setName(rs.getString("Name"));
				ne.setId(rs.getInt("id"));
				ne.setGroup(rs.getString("group"));
				ne.setPhone(rs.getString("phone"));
				ne.setClas(rs.getString("clas"));
				ne.setAddress(rs.getString("address"));
				ne.setDormitory(rs.getString("dormitory"));
				ne.setEmail(rs.getString("email"));
				ar.add(ne);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return ar;
	}

			/**
			 * ģ������
			 */
	public ArrayList<member> getList2(String name) {// ������ѯ
		ArrayList<member> ar = new ArrayList<member>();
		Connection conn = BaseConnection.getConnection();			
		ResultSet rs = null;
		try {
			String sql = "select * from member where name like ?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, "%"+name+"%");
			rs = ps.executeQuery();
			while (rs.next()) {
				member ne = new member();
				ne.setName(rs.getString("Name"));
				ne.setId(rs.getInt("id"));
				ne.setGroup(rs.getString("group"));
				ne.setPhone(rs.getString("phone"));
				ne.setClas(rs.getString("clas"));
				ne.setAddress(rs.getString("address"));
				ne.setDormitory(rs.getString("dormitory"));
				ne.setEmail(rs.getString("email"));
				ar.add(ne);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				/*if (ps!= null) {
					ps.close();
				}*/
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return ar;
	}

	/**
	 * �÷������𽫴��ݹ�����news�����е����ݴ��뵽���ݿ���
	 * 
	 * @param ne
	 * @throws SQLException 
	 */
	public static void insert(member ne) throws SQLException {
		Connection conn = BaseConnection.getConnection();
		String sql = "insert into member values(?,?,?,?,?,?,?,?)";
		PreparedStatement ps = conn.prepareStatement(sql);
		try {
			ps.setInt(1, ne.getId());
			ps.setString(2, ne.getName());
			ps.setString(3, ne.getGroup());
			ps.setString(4, ne.getClas());
			ps.setString(5, ne.getPhone());
			ps.setString(6, ne.getEmail());
			ps.setString(7, ne.getDormitory());
			ps.setString(8, ne.getAddress());
			int a = ps.executeUpdate();// ����������ڸı����ݿ����ݣ�a�����ı����ݿ������
			if (a > 0) {
				System.out.println("���ӳɹ�");
			} else {
				System.out.println("����ʧ��");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			if (ps != null) {
				ps.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch (Exception e2) {
			e2.printStackTrace();
		}
	}

	/**
	 * �����ݿ���ɾ��Ԫ��
	 * 
	 * @param args
	 */
	public static void delete(int id) {
		Connection con = BaseConnection.getConnection();
		PreparedStatement ps = null;
		String sql = "delete from member where id = ?";
		try {
			ps = con.prepareStatement(sql);
			ps.setInt(1, id);
			int a = ps.executeUpdate();
			if (a > 0) {
				System.out.println("ɾ���ɹ�");
			} else {
				System.out.println("ɾ��ʧ��");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * �����޸Ĳ���
	 * 
	 * @param args
	 * @throws SQLException 
	 */
	public static int update(member k) throws Exception {
		Connection con = BaseConnection.getConnection();
		String sql = " update member set name=?,group=?,clas=?,phone=?,email=?,dormitory=?,address=? where id=? ";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, k.getName());
		ps.setString(2, k.getGroup());
		ps.setString(3, k.getClas());
		ps.setString(4, k.getPhone());
		ps.setString(5, k.getEmail());
		ps.setString(6, k.getDormitory());
		ps.setString(7, k.getAddress());
		ps.setInt(8, k.getId());
		int result = ps.executeUpdate();
		ps.close();
		con.close();
		return 0;
		
	}
	
		


   public static Object[][] queryData(){
    	ArrayList<member> list = new memberDAO().getList();
    	Object[][] data=new Object[list.size()][8];
        for(int i=0;i<list.size();i++){   
        	for(int j=0;j<8;j++) {
                data[i][0]=list.get(i).getId();
                data[i][1]=list.get(i).getName();
                data[i][2]=list.get(i).getGroup();
                data[i][3]=list.get(i).getClas();
                data[i][4]=list.get(i).getPhone();
                data[i][5]=list.get(i).getEmail();
                data[i][6]=list.get(i).getDormitory();
                data[i][7]=list.get(i).getAddress();   
        	}
        }
        return data;
    }
    public static Object[][] queryData2(String k){
    	ArrayList<member> list = new memberDAO().getList2(k);
    	Object[][] data=new Object[list.size()][8];
        for(int i=0;i<list.size();i++){   
        	for(int j=0;j<8;j++) {
                data[i][0]=list.get(i).getId();
                data[i][1]=list.get(i).getName();
                data[i][2]=list.get(i).getGroup();
                data[i][3]=list.get(i).getClas();
                data[i][4]=list.get(i).getPhone();
                data[i][5]=list.get(i).getEmail();
                data[i][6]=list.get(i).getDormitory();
                data[i][7]=list.get(i).getAddress();   
        	}
        }

        return data;
    }
    
    public static ArrayList<member> queryDatak(int k) {
    	ArrayList<member> ar = new ArrayList<member>();
    	Connection conn = BaseConnection.getConnection();
    	PreparedStatement ps = null;
    	ResultSet rs = null;
    	try {
			String sql = "select*from member where id = "+k;
			ps = conn.prepareStatement(sql);
			rs = ps.executeQuery();// ִ�����ݿ��ѯ�ķ������ŵ�rs��
			while (rs.next()) {// rs�����൱��һ��ָ�룬ָ�����ݿ��һ��������
				member ne = new member();// ��װ����
				ne.setName(rs.getString("Name"));
				ne.setId(rs.getInt("id"));// rsָ��ָ��idһ�л�ȡidһ�����ݣ��洢��ne��
				ne.setGroup(rs.getString("group"));// rsָ��ָ��titleһ�л�ȡidһ�����ݣ��洢��ne��
				ne.setPhone(rs.getString("phone"));// rsָ��ָ��contentһ�л�ȡidһ�����ݣ��洢��ne��
				ne.setClas(rs.getString("clas"));// rsָ��ָ��idһ�л�ȡtypeһ�����ݣ��洢��ne��
				ne.setAddress(rs.getString("address"));
				ne.setDormitory(rs.getString("dormitory"));
				ne.setEmail(rs.getString("email"));
				ar.add(ne);// ͨ��ѭ���������ݵ��������δ洢��ne�����У��ٰ�ne�������ӵ�ar�����з�����ȡ
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {// �ص�����������д�������ݿ�ʹ�ú����رգ����û�йر����ݿ�Ľӿ����ޣ��´ξͲ�������
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
				if (conn != null) {
					conn.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return ar;// ����ar
    }
    
	public static void main(String []args) throws Exception {
		//memberDAO.delete(2);
		
		/* ArrayList<member> ar = new memberDAO().queryDatak(2);
		 for(member e : ar) {
			 System.out.println(e.getAddress());
		 }
		*/

		
		 /*member ak = new member(); 
		 //ak.setId(3); 
		 ak.setName("353");
		 ak.setAddress("6565");
		 ak.setDormitory("23");
		 ak.setClas("97");
		 ak.setEmail("32200");
		 ak.setPhone("42343824");
		 ak.setGroup("4234324322");
		 
		// NewsDAO.insert(ak);
		// NewsDAO.delete(312);

		memberDAO.insert(ak);*/
			
		
		// System.out.println(ak.getId());
		String o = "��";
		queryData2(o);
	}

}
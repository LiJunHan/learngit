package com.LinJunhan.dao;

import com.LinJunhan.model.*;
import com.LinJunhan.util.*;
import java.util.*;
import java.sql.*;


public class userDAO {
	/**
	 * ��ȡ���ݿ�����
	 * 
	 * @return
	 */
	public static ArrayList<user> getList2() {
		ArrayList<user> f = new ArrayList<user>();
		Connection con = BaseConnection.getConnection();
		PreparedStatement rp = null;
		ResultSet rs = null;
		try {
			String sql = "select * from user";
			rp = con.prepareStatement(sql);
			rs = rp.executeQuery();
			while (rs.next()) {
				user k = new user();
				k.setId(rs.getString("id"));
				k.setPassword(rs.getString("password"));
				f.add(k);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (rp != null) {
				try {
					rp.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return f;
	}

	/**
	 * ������д�����ݿ�
	 * @param args
	 */
	public static void insert(user k) {
		Connection con = BaseConnection.getConnection();
		PreparedStatement ps = null;
		String sql="insert into user(password,id)"+  
				"values('" + k.getPassword() + "'," + k.getId() + ")";
		try {
			ps=con.prepareStatement(sql);
			int a = ps.executeUpdate();
			if(a>0) {
				System.out.println("����ɹ�");
			}else {
				System.out.println("����ʧ��");
			}
			}catch(Exception e) {
				e.printStackTrace();
			try {
				if(ps!=null) {
					ps.close();
				}
				if(con!=null) {
					con.close();
				}
			}catch(Exception e2) {
				e2.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		ArrayList<user> list = new userDAO().getList2();
		for (user k : list) {
			System.out.println(k.getId()+" "+k.getPassword());
		}
	}
}
	
package com.LinJunhan.service;

import com.LinJunhan.view.*;

public class QG��ԱͨѶ¼ϵͳ {
	public static void main(String[] args) {
		WindowFace.launchFrame();
}
	
}

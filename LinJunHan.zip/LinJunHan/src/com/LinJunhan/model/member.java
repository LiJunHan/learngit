package com.LinJunhan.model;

public class member {
	private int id;
	private String name;
	private String group;
	private String phone;
	private String clas;
	private String email;
	private String dormitory;
	private String address;

	public void setId(int id) {
		this.id = id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setClas(String clas) {
		this.clas = clas;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setDormitory(String dormitory) {
		this.dormitory = dormitory;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getGroup() {
		return group;
	}

	public String getPhone() {
		return phone;
	}

	public String getClas() {
		return clas;
	}

	public String getEmail() {
		return email;
	}

	public String getDormitory() {
		return dormitory;
	}

	public String getAddress() {
		return address;
	}

	public String toString() {
		return ("'"+name+"'"+","+"'"+group+"'"+","+"'"+clas+"'"+","+"'"+phone+"'"+","+"'"+email+"'"+","+"'"+dormitory+"'"+","+"'"+address+"'");
	}
}

package com.LinJunhan.view;

import java.awt.*;
import javax.swing.*;

import com.LinJunhan.dao.memberDAO;

import java.awt.event.*;

public class Search {
	public static void search() {
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame s = new JFrame("����");
		ImageIcon icon = new ImageIcon("C:\\logo\\QG1.jpg");
		Image image = icon.getImage();
		s.setIconImage(image);
		s.setBounds(550, 250, 300, 200);
		JPanel p1 = new JPanel();
		JPanel p2 = new JPanel();
		s.setLayout(new GridLayout(2,1));
		s.add(p1);
		s.add(p2);
		JLabel l = new JLabel("��������Ҫ���ص���Ϣ");
		JTextField f = new JTextField();
		f.setColumns(15);
		p1.setLayout(new GridLayout(2,1));
		p1.add(l);
		p1.add(f);
		JButton b = new JButton("����");
		p2.add(b);
		b.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				String k = f.getText().trim();
				Object[][] tableDate;
				tableDate= memberDAO.queryData2(k);
				if(tableDate[0][1]!=null) {
					JFrame.setDefaultLookAndFeelDecorated(true);
					JFrame fo = new JFrame("����");
					JPanel p1 = new JPanel();
					JPanel p2 = new JPanel();
					//p1.setBounds(0, 0, 500, );
					fo.setLayout(new GridLayout(2,1));
					fo.setBounds(600, 300, 500, 300);
					ImageIcon icon = new ImageIcon("C:\\logo\\QG1.jpg");
					Image image = icon.getImage();
					fo.setIconImage(image);
					JTable table;
					Object[] columnTitle = { "id", "����", "רҵ�༶", "�꼶", "�绰", "����", "����", "��ַ" };
					table = new JTable(tableDate, columnTitle);
					p1.add(new JScrollPane(table));					
					//fo.add(new JScrollPane(table));
					JButton b = new JButton("�ر�");
					b.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							fo.setVisible(false);
						}
					});
					p2.add(b);
					fo.add(p1);
					fo.add(p2);
					fo.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					fo.setVisible(true);
					
				}
				else {
					JFrame.setDefaultLookAndFeelDecorated(true);
					JFrame frame = new JFrame("�޸ĳ�Ա��Ϣ");
					frame.setBounds(600, 300, 200, 100);
					ImageIcon icon = new ImageIcon("C:\\logo\\QG1.jpg");
					Image image = icon.getImage();
					frame.setIconImage(image);
					JLabel l = new JLabel("    			  	û���ҵ�����Ҫ����Ϣ��   			     ");
					JButton b = new JButton("�ر�");
					b.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							frame.setVisible(false);
						}
					});
					frame.setLayout(new GridLayout(2, 1));
					JPanel a1 = new JPanel();
					JPanel a2 = new JPanel();
					frame.add(a1);
					frame.add(a2);
					a1.add(l);
					a2.add(b);
					frame.pack();
					frame.setVisible(true);
				}
			}
		});
		s.setVisible(true);
	}
	public static void main(String[] args) {
		search();
	}
}

package com.LinJunhan.view;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;

import com.LinJunhan.dao.memberDAO;
import com.LinJunhan.model.member;

public class XiuGaiFace {
	static int n = 0;

	public static void xiuGaiFace() {
		/**
		 * �����µĿ��
		 */
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame frame = new JFrame("�޸ĳ�Ա��Ϣ");
		frame.setBounds(550, 250, 200, 150);
		frame.setLayout(new FlowLayout());
		ImageIcon icon = new ImageIcon("C:\\logo\\QG1.jpg");
		Image image = icon.getImage();
		frame.setIconImage(image);
		/**
		 * /** �����������
		 */
		JPanel panel1 = new JPanel();
		JPanel panel2 = new JPanel();
		frame.add(panel1);
		frame.add(panel2);
		/**
		 * ������ǩ���ı���
		 */
		JLabel label = new JLabel("��������Ҫ�޸ĵĳ�ԱID");
		JTextField ae = new JTextField();

		ae.setColumns(8);
		panel1.add(label);
		panel2.add(ae);
		/*
		 * ������ť
		 */
		JButton button1 = new JButton("����");
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String value = ae.getText().trim();
				n = Integer.parseInt(value); // ���ַ������͵�����ת������
				frame.setVisible(false);
				XiuGaiFace.xiuGaiEnd();
			}
		});
		panel2.add(button1);
		frame.pack();
		frame.setVisible(true);
	}

	public static void xiuGaiFace2() {
		ArrayList<member> list = new memberDAO().queryDatak(n);
		/**
		 * ����һ�����
		 */
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame frame = new JFrame("�޸ĳ�Ա��Ϣ");
		frame.setBounds(550, 200, 500, 600);
		frame.setLayout(new GridLayout(8, 1));
		ImageIcon icon = new ImageIcon("C:\\logo\\QG1.jpg");
		Image image = icon.getImage();
		frame.setIconImage(image);
		/**
		 * /** ����8�����
		 */
		JPanel a1 = new JPanel();
		JPanel a2 = new JPanel();
		JPanel a3 = new JPanel();
		JPanel a4 = new JPanel();
		JPanel a5 = new JPanel();
		JPanel a6 = new JPanel();
		JPanel a7 = new JPanel();
		JPanel a8 = new JPanel();
		a1.setLayout(new GridLayout(2, 1));
		a2.setLayout(new GridLayout(2, 1));
		a3.setLayout(new GridLayout(2, 1));
		a4.setLayout(new GridLayout(2, 1));
		a5.setLayout(new GridLayout(2, 1));
		a6.setLayout(new GridLayout(2, 1));
		a7.setLayout(new GridLayout(2, 1));
		frame.add(a1);
		frame.add(a2);
		frame.add(a3);
		frame.add(a4);
		frame.add(a5);
		frame.add(a6);
		frame.add(a7);
		frame.add(a8);
		/**
		 * ����7����ǩ��7���ı���
		 */
		JLabel t1 = new JLabel("������");
		JLabel t2 = new JLabel("רҵ�༶��");
		JLabel t3 = new JLabel("�꼶��");
		JLabel t4 = new JLabel("�绰��");
		JLabel t5 = new JLabel("���䣺");
		JLabel t6 = new JLabel("���᣺");
		JLabel t7 = new JLabel("��ַ��");
		JTextField f1 = new JTextField();
		JTextField f2 = new JTextField();
		JTextField f3 = new JTextField();
		JTextField f4 = new JTextField();
		JTextField f5 = new JTextField();
		JTextField f6 = new JTextField();
		JTextField f7 = new JTextField();
		for (member e : list) {
			f1.setText(e.getName());
			f2.setText(e.getGroup());
			f3.setText(e.getClas());
			f4.setText(e.getPhone());
			f5.setText(e.getEmail());
			f6.setText(e.getDormitory());
			f7.setText(e.getAddress());
		}
		f1.setColumns(20);
		f2.setColumns(20);
		f3.setColumns(20);
		f4.setColumns(20);
		f5.setColumns(20);
		f6.setColumns(20);
		f7.setColumns(20);
		a1.add(t1);
		a2.add(t2);
		a3.add(t3);
		a4.add(t4);
		a5.add(t5);
		a6.add(t6);
		a7.add(t7);
		a1.add(f1);
		a2.add(f2);
		a3.add(f3);
		a4.add(f4);
		a5.add(f5);
		a6.add(f6);
		a7.add(f7);
		/**
		 * ������ť
		 */
		JButton b1 = new JButton("ȷ���޸�");
		b1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String b1 = t1.getText().trim();
				String b2 = t2.getText().trim();
				String b3 = t3.getText().trim();
				String b4 = t4.getText().trim();
				String b5 = t5.getText().trim();
				String b6 = t6.getText().trim();
				String b7 = t7.getText().trim();
				member ar = new member();
				ar.setId(n);
				ar.setName(b1);
				ar.setGroup(b2);
				ar.setClas(b3);
				ar.setPhone(b4);
				ar.setAddress(b5);
				ar.setDormitory(b6);
				ar.setAddress(b7);
				memberDAO.update(ar);
				frame.setVisible(false);
				XiuGaiFace.xiuGaiEnd();
			}
		});
		a8.add(b1);
		frame.pack();
		frame.setVisible(true);
	}

	public static void xiuGaiEnd() {
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame frame = new JFrame("�޸ĳ�Ա��Ϣ");
		frame.setBounds(600, 300, 200, 100);
		ImageIcon icon = new ImageIcon("C:\\logo\\QG1.jpg");
		Image image = icon.getImage();
		frame.setIconImage(image);
		JLabel l = new JLabel("    			  	�ù�����δ���٣������ڴ���   			     ");
		JButton b = new JButton("�ر�");
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
			}
		});
		frame.setLayout(new GridLayout(2, 1));
		JPanel a1 = new JPanel();
		JPanel a2 = new JPanel();
		frame.add(a1);
		frame.add(a2);
		a1.add(l);
		a2.add(b);
		frame.pack();
		frame.setVisible(true);
	}

	public static void main(String[] args) {
		xiuGaiFace();
		// xiuGaiFace2();
		// xiuGaiEnd();
	}
}

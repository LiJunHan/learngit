package com.LinJunhan.view;

import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.*;
import com.LinJunhan.dao.memberDAO;
import com.LinJunhan.dao.userDAO;
import com.LinJunhan.model.member;
import com.LinJunhan.model.user;

public class ChengYuanjiemian {
	public static void memberList() {
		/**
		 * ���������
		 */
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame frame = new JFrame("QG�����ҳ�ԱͨѶ¼");
		frame.setBounds(200, 125, 1500, 600);
		frame.setLayout(new FlowLayout());
		/**
		 * �����������
		 */
		JPanel pane1 = new JPanel();
		JPanel pane2 = new JPanel();
		frame.add(pane1);
		frame.add(pane2);
		pane2.setLayout(new GridLayout(4,1));
		/**
		 * ���붥��ͼ��
		 */
		ImageIcon icon = new ImageIcon("C:\\logo\\QG1.jpg");
		Image image = icon.getImage();
		frame.setIconImage(image);
		/**
		 * �������
		 */
		JTable table;// ����һ������
		Object[][] tableData;
		tableData = memberDAO.queryData();
		Object[] columnTitle = { "id", "����", "רҵ�༶", "�꼶", "�绰", "����", "����", "��ַ" };
		table = new JTable(tableData, columnTitle);
		//pane1.add(table);
		frame.add(new JScrollPane(table));
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		/**
		 * ����������ť�������汾
		 */
		JButton button1 = new JButton("ɾ����Ա��Ϣ");
		JButton button2 = new JButton("���ӳ�Ա��Ϣ");
		JButton button3 = new JButton("�޸ĳ�Ա��Ϣ");
		JButton button4 = new JButton("������Ա");
		button1.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) { 
				 	frame.setVisible(false);
	                DelectFace.delectFace();
	            }  
	        });   
		button2.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) { 
				 	frame.setVisible(false);
	                AddFace.addFace();
	            }  
	        });  
		button3.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) { 
				 	XiuGaiFace.xiuGaiEnd();
	            }  
	        });
		button4.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				Search.search();
			}
		});
	// pane2.setLayout(new GridBagLayout());
	// GridBagConstraints c = new GridBagConstraints();
	// c.ipady = 3;
	pane2.add(button1);pane2.add(button2);pane2.add(button3);pane2.add(button4);frame.pack();frame.setVisible(true);

	}

	public static void main(String[] args) {
		memberList();
	}

}

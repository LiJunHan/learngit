package com.LinJunhan.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import com.LinJunhan.model.*;
import com.LinJunhan.dao.*;

public class Register {
	public static void register() {
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame re = new JFrame();
		re.setBounds(550, 250, 300, 300);
		re.setLayout(new GridLayout(3,1));
		JPanel p1 = new JPanel();
		JPanel p2 = new JPanel();
		p1.setLayout(new FlowLayout());
		p2.setLayout(new FlowLayout());
		JPanel p3 = new JPanel();
		p3.setLayout(new FlowLayout());
		JLabel l1 = new JLabel("�û���");
		JLabel l2 = new JLabel("����");
		JTextField t1 = new JTextField();
		JTextField t2 = new JTextField();
		JButton b = new JButton("ȷ��ע��");
		t1.setColumns(20);
		t2.setColumns(20);
		re.add(p1);
		re.add(p2);
		re.add(p3);
		p1.add(l1);
		p1.add(t1);
		p2.add(l2);
		p2.add(t2);
		p3.add(b);
		re.setVisible(true);
		b.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				user m = new user();
				m.setId(t1.getText().trim());
				m.setPassword(t2.getText().trim());
				userDAO.insert(m);
				re.setVisible(false);
				register3();
			}
				});}
	
	public static void register3() {
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame frame = new JFrame("ע��");
		frame.setBounds(600, 300, 200, 100);
		frame.setLayout(new GridLayout(2,1));
		JPanel p1 = new JPanel();
		JPanel p2 = new JPanel();
		frame.add(p1);
		frame.add(p2);
		ImageIcon icon = new ImageIcon("C:\\logo\\u=591068368,2095718541&fm=200&gp=0.jpg");
		Image image = icon.getImage();
		frame.setIconImage(image);
		JLabel l = new JLabel("    			  	ע��ɹ���    			     ");
		JButton b = new JButton("�ر�");
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
			}
		});
		p1.add(l);
		p2.add(b);
		frame.setVisible(true);
	}
	public static void register4() {
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame frame = new JFrame("����");
		frame.setBounds(600, 300, 200, 100);
		frame.setLayout(new GridLayout(2,1));
		JPanel p1 = new JPanel();
		JPanel p2 = new JPanel();
		frame.add(p1);
		frame.add(p2);
		ImageIcon icon = new ImageIcon("C:\\logo\\QG1.jpg");
		Image image = icon.getImage();
		frame.setIconImage(image);
		JLabel l = new JLabel("    			  	����ϵϵͳ����Ա��    			     ");
		JButton b = new JButton("�ر�");
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.setVisible(false);
			}
		});
		p1.add(l);
		p2.add(b);
		frame.setVisible(true);
	}
	
	public static void main(String[] args) {
		register();
	}
}

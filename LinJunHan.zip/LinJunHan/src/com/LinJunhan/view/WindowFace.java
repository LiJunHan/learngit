package com.LinJunhan.view;

import java.awt.*;
import com.LinJunhan.model.*;
import com.LinJunhan.dao.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;

//import GUI.TFFrame.MyWindowMonitor;

public class WindowFace {
	
	
	
	
	public static void main(String[] args) {
		launchFrame();
	}

	public static void launchFrame() {
		 
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame f = new JFrame("QG��ԱͨѶ¼");
		ImageIcon icon = new ImageIcon("C:\\logo\\QG1.jpg");
		Image image = icon.getImage();
		f.setIconImage(image);
		f.setBounds(380, 300, 0, 0);
		//f.setLayout(null);
		JPanel p1 = new JPanel();
		JPanel p2 = new JPanel();
		JPanel p3 = new JPanel();
		JPanel p4 = new JPanel();
		// p1.set
		p1.setLayout(new FlowLayout());
		p2.setLayout(new FlowLayout());
		p3.setLayout(new GridLayout(4, 1));
		JTextField number = new JTextField(20);
		number.setColumns(20);
		JPasswordField password = new JPasswordField(20);
		password.setColumns(20);
		 JPanel contentPane=new JPanel(){  
			 	Image image;
	            public void paint(Graphics g) {  
	                ImageIcon icon=new ImageIcon("C:\\logo\\u=1159651309,3118574949&fm=27&gp=0.jpg");  
	                image=icon.getImage();  
	        // g.drawImage(image, 0,0,);  	 
	                g.drawImage(image, 500, 500, 500, 500, 500, 500,500, 500, null);
	            }  
	        };     
	        f.add(contentPane); 
		Label symbol1 = new Label("�ʻ���:");
		Label symbol2 = new Label("����:");
		JButton button1 = new JButton("��¼");
		JButton button2 = new JButton("ע���ʺ�");
		JButton button3 = new JButton("�һ�����");
		JButton button4 = new JButton("����");

		button1.setBounds(0, 0, 50, 25);
		//MyListener simpleListener = new MyListener();
		f.setLayout(new GridLayout(5, 2));
		button1.setBackground(Color.pink);
		p1.add(symbol1);
		p1.add(number);
		p1.add(symbol2);
		p1.add(password);
		p1.add(button1);
		// gbc.gridwidth = GridBagConstraints.REMAINDER;
		p1.add(button2);
		p1.add(button3);
		p1.add(button4);
		f.add(contentPane);
		f.add(p1);
		//f.add(p2);
		//f.add(p3);
		button1.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) { 
				 	ArrayList<user> list = userDAO.getList2();
				 	int n= 0;
				 	String v1 = number.getText().trim();
				 	char[] v = password.getPassword();
				 	String v2 = new String(v);
				 	
				 	for(user e1 : list) {	 
				 	 
				 		System.out.println(e1.getId()+" "+e1.getPassword());
				 		System.out.println(v1+" "+v2);
				 		if((v1.equals(e1.getId()))&&(v2.equals(e1.getPassword()))){
				 			f.setVisible(false);
				 			ChengYuanjiemian.memberList();
				 			n=9;
				 		}
				 		
				 	}
				 	if(n==0) {
	                 dengLutEnd();}
	            }  
	        });  
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Register.register();
				f.setVisible(false);
			}
		});
		button3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Register.register4();
			}
		});
		button4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Register.register4();
			}
		});
		f.pack();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setVisible(true);
	}
	public static void dengLutEnd() {
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame frame = new JFrame("QG��ԱͨѶ¼");
		frame.setBounds(600, 300, 200, 100);
		frame.setLayout(new GridLayout(2,1));
		JPanel p1 = new JPanel();
		JPanel p2 = new JPanel();
		frame.add(p1);
		frame.add(p2);
		ImageIcon icon = new ImageIcon("C:\\logo\\QG1.jpg");
		Image image = icon.getImage();
		frame.setIconImage(image);
		JLabel l = new JLabel("    			  	��������˺Ż�����������    			     ");
		JButton b = new JButton("�ر�");
		p1.add(l);
		p2.add(b);
		frame.setVisible(true);
		b.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) { 
				 	frame.setVisible(false);
				 	launchFrame();
	            }  
	        });}
		
	
	/*class MyListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			String buttonName = e.getActionCommand();
			if (buttonName.equals("��¼")) {
				
				

			}

		}
	}*/

}
